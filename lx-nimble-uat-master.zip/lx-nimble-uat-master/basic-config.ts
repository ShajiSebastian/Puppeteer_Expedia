const basicConfig = {
    baseUrl: `https://wwwexpediacom.trunk.sb.karmalab.net/`,
    loginUrl: `https://wwwexpediacom.trunk.sb.karmalab.net/devtools/login`,
    getLoginUrl(email: string, pass: string) {
        return `${this.loginUrl}?email=${email}&password=${pass}`;
    },
    getsearchUrl(location: string) {
        return `${this.baseUrl}things-to-do/search?location=${location}`;
    },
    getISUrl(activityid: string) {
        return `${this.baseUrl}things-to-do/a.a${activityid}.a`;
    },
};
export default basicConfig;
