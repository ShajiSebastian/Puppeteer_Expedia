const fs = require("fs");
const PuppeteerEnvironment = require("jest-environment-puppeteer");
require("jest-circus");

const retryAttempts = process.env.RETRY_ATTEMPTS || 1;

class CustomEnvironment extends PuppeteerEnvironment {

  async setup() {
    await super.setup();
  }

  async teardown() {
    // Wait a few seconds before tearing down the page so we
    // have time to take screenshots and handle other events
    try {
      await this.global.page.waitFor(2000);
    } catch (err) {
      console.error(err.message);
    }
    await super.teardown();
  }

  async handleTestEvent(event, state) {
    const testName = state && state.currentlyRunningTest && state.currentlyRunningTest.name ? state.currentlyRunningTest.name.trim() : null;
    if (event.name == "test_fn_failure" && testName) {
      try {
        await this.global.page.screenshot({ path: `test-report/screenshots/${testName}.png` });
      } catch (err) {
        console.error(err.message);
      }
    }
  }

}

module.exports = CustomEnvironment;
