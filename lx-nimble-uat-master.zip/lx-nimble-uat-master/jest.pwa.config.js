module.exports = {
    "roots": [
        "<rootDir>/tests",
    ],
    setupFilesAfterEnv: ["<rootDir>/jest-setup.js"],
    "transform": {
        "^.+\\.tsx?$": "ts-jest",
    },
    testMatch: [
                "**/tests/**/pwa/**/*.tests.ts",
                "**/tests/**/pwa/**/*.ts",
              ],
    "moduleFileExtensions": [
        "ts",
        "tsx",
        "js",
        "jsx",
        "json",
        "node",
    ],
    "preset": "jest-puppeteer",
    "reporters": [
        "default",
        ["./node_modules/jest-html-reporter", {
            "pageTitle": "Test Report",
            outputPath: "./test-report/test-report.html",
            includeFailureMsg: true,
            includeConsoleLog: true,
        }],
    ],
    testRunner: "jest-circus/runner",
    maxWorkers: 1,
    testEnvironment: "./custom-environment.js",
    globals: {
        "testEnv": "test",
        "ts-jest": {
          diagnostics: false,
        },
      },
};
