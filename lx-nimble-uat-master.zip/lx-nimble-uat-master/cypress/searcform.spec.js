context("Querying", () => {
      beforeEach(() => {
        cy.visit("https://lx-nimble.us-west-2.test.expedia.com/activitiesSearch");
      });

      it("Destination Error Message", () => {
        cy.get('button[data-stid="activities-destination-dialog-trigger"]').click();

        cy.get('input[data-stid="activities-destination-dialog-input"]').type("Rome");
        cy.get('input[data-stid="activities-destination-dialog-input"]').type("{enter}");

        cy.get('button[data-stid="activities-destination-dialog-trigger"]').click();
        cy.get('input[data-stid="activities-destination-dialog-input"]').type("{del}{selectall}{backspace}");
        cy.get('input[data-stid="activities-destination-dialog-input"]').type("{enter}");

        cy.get(".uitk-typeahead .uitk-validation-error").contains("Destination not selected.");
      });
});
