
context("Querying", () => {
      beforeEach(() => {
      cy.viewport("iphone-5");
      cy.visit(getEndPoint() + "tools/abacus/overrides?abov=29685|1|1:31112|1|1");

      });

  // new uat test for pwa default activity search

      it("Verify PWA default activity search resut", () => {
        cy.visit("/things-to-do/search?location=Rome");
        cy.wait(5000);
        cy.get(".all-x-padding-three > :nth-child(1) > .uitk-button > .uitk-button-container").click();
        cy.get("#radio-RECOMMENDED").should("be.checked");

       });

// Slim search
      it("verify_Slim_Search_On_Change_Search", () => {
        cy.visit("/things-to-do/search?location=Rome");
        cy.wait(5000);
        cy.get(".all-x-padding-three > :nth-child(1) > .uitk-button > .uitk-button-container").click();
        cy.get(".uitk-field-input").type("tour");
        cy.get(".uitk-field-input").type("{enter}");
        cy.wait(15000);
        console.log(cy.get(".uitk-pill-text"));
        cy.get(".uitk-pill-text").contains("tour");
        cy.url().should("include", "SearchKeyword=tour");
        cy.wait(2000);
        cy.get('.uitk-type-center > .uitk-icon > [aria-hidden="true"]').click();
        cy.wait(2000);
        cy.get(".uitk-typeahead > .uitk-field > .uitk-faux-input").click();
        cy.get(Cypress.env("destinationPopup")).clear();
        cy.get(Cypress.env("destinationPopup")).type("Rome");
        cy.get(Cypress.env("destinationPopup")).type("{enter}");
        cy.wait(15000);
        cy.url().should("not.contain", "SearchKeyword=tour");

        });

      //Slim search
      it("Slim search", () => {
         cy.visit("/things-to-do/search?location=Rome");
         cy.wait(5000);
         cy.get(".all-x-padding-three > :nth-child(1) > .uitk-button > .uitk-button-container").click();
         cy.get(".uitk-field-input").type("tour");
         cy.get(".uitk-field-input").type("{enter}");
         cy.wait(15000);
         console.log(cy.get(".uitk-pill-text"));
         //cy.get('.uitk-pill-text').should('have.value', 'Rome');
         cy.get(".uitk-pill-text").contains("tour");
         cy.url().should("include", "SearchKeyword=tour");
         cy.get('.uitk-pill-content > .uitk-icon > [aria-hidden="true"]').click();
         cy.wait(15000);
         //cy.get('.check-box-sub-text').should('not.exist');
         cy.url().should("not.contain", "SearchKeyword=tour");

         });

     // Change saerch

      it("Change search", () => {
         cy.visit("/things-to-do/search?location=Rome");
         //cy.wait(5000);
         cy.get(".uitk-cell > .uitk-type-400").click();
         cy.get(".uitk-typeahead > .uitk-field > .uitk-faux-input").click();
         //cy.get(Cypress.env("destinationPopup")).click();
         cy.get(Cypress.env("destinationPopup")).clear();
         cy.get(Cypress.env("destinationPopup")).type("London");
         cy.get(Cypress.env("destinationPopup")).type("{enter}");
         cy.url().should("include", "London");

        });

      // Filter test
      it("Family friendly Picks filter", () => {
        cy.visit("/things-to-do/search?location=Rome");
        cy.wait(15000);
        cy.get(".all-x-padding-three > :nth-child(1) > .uitk-button > .uitk-button-container").click();
        cy.get("[id^=cb-Family]").click();
        //cy.get('[id^=cb-Local]').click();
        cy.xpath('//*[@id="app"]/div/div[2]/div/div/form/div[2]/button/span').click();
        cy.wait(15000);
        cy.get(".uitk-pill-text").and("contain", "Family friendly");

        });

     // MOD banner test

      it("SRP mod banner", () => {

       cy.request("/devtools/login?email=localexpertmod@gmail.com&password=expedia123");
       cy.wait(5000);
       cy.visit("/things-to-do/search?location=Rome");
       cy.wait(5000);
       cy.get(":nth-child(2) > .uitk-card-media > .uitk-image > :nth-child(1) > .lx-tl-figure-badge > .uitk-badge-text").should("be.visible").and("contain", "Member price");

       });

/*
      // SRP MIP banner Test

      it('Verify MIP banner in SRP page', () => {
      const mipBannerText = 'Exclusive Offer!'
      cy.request('/devtools/login?email=v-neaggarwal@expedia.com&password=expedia');
      cy.wait(5000);
      cy.visit('/things-to-do/search?location=Rome');
      cy.wait(5000);
      cy.get('.lx-tl-figure-badge').and('contain', mipBannerText)
        cy.document().then((doc) => {
          console.log(doc.getElementsByClassName('lx-tl-figure-badge'));
          //doc.getElementsByClassName('lx-tl-figure-badge').length > 0
          console.log(doc.getElementsByClassName('lx-tl-figure-badge').length);
          var exclusiveOffers = doc.getElementsByClassName('lx-tl-figure-badge');
          if (exclusiveOffers.length>0){
            exclusiveOffers[0].textContent;
          }
        });
      });

*/
      it("Verify Date change search", () => {
     cy.visit("/things-to-do/search?location=Rome");
     cy.wait(5000);
     cy.get(".uitk-cell > .uitk-type-400").click();
     //cy.get(Cypress.env("destinationButton")).click();
     cy.get("#activity-start-date__btn").click();
     cy.get(".uitk-date-picker-day-number.start").next().next().click();
     cy.get(".uitk-scrim > .uitk-button > .uitk-button-container").click();
     //cy.get(':nth-child(9) > .uitk-card-media > .uitk-image > :nth-child(1) > .lx-tl-figure-badge > .uitk-badge-text').and('contain', mipBannerText)

     });

});
