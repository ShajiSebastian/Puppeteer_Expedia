context("Querying", () => {
      beforeEach(() => {
      cy.viewport("iphone-5");
      cy.visit("/tools/abacus/overrides?abov=29685|1|1:31112|1|1:13942|1|1:24507|1|1:27058|1|1:27190|0|0:27242|0|0");

      });

      it("Verify Infosite Page", () => {
           cy.visit("/things-to-do/a.a166597.a");
           cy.wait(10000);
           const activityTitle = "Faster Than Skip-the-Line: Vatican, Sistine Chapel and St. Peter's Tour";
           const otherRecommended = "Other recommended activities";
           const knowBefore = "Know Before You Book";
           const included = "What's included";
           const highlights = "Highlights";
           const location = "Location";
           const checkAvailability = "Check Availability";
           const moreDate = "More Dates";
           const review = "Expedia verified review";

           //Verify the activity title is coming correctily in the IS page
           cy.get(".all-y-padding-three > .uitk-type-heading-600").and("contain", activityTitle);
           cy.get("#recommendation-list > .uitk-type-heading-600").and("contain", otherRecommended);
           cy.get(":nth-child(4) > .uitk-type-heading-600").and("contain", knowBefore);
           cy.get("#activity-map > .uitk-type-heading-600").and("contain", location);
           cy.get(":nth-child(2) > .uitk-type-heading-600").and("contain", highlights);
           cy.get(":nth-child(3) > .uitk-type-heading-600").and("contain", included);
           cy.get(":nth-child(1) > :nth-child(3) > .uitk-type-heading-600").and("contain", checkAvailability);
           //cy.get('#check-availability-header > div > .uitk-type-300') .and('contain', moreDate);
           cy.get(":nth-child(1) > :nth-child(2) > .uitk-flex-justify-content-space-between > div > .uitk-link").and("contain", review);
           cy.get("a > .uitk-image > .uitk-image-placeholder > .uitk-image-media").should("be.visible");
           cy.get(":nth-child(1) > :nth-child(2) > .uitk-flex-justify-content-space-between > div > .uitk-link").should("be.visible").click();

           });

      it("verify_check_availability_atf", () => {
           cy.wait(5000);
           cy.visit("/things-to-do/a.a166442.a");
           cy.wait(5000);
           cy.get("#check-availability-header > div > .uitk-type-300").click();
           cy.get(".uitk-date-picker-day-number.start").next().click();
           cy.get(".uitk-scrim > .uitk-button > .uitk-button-container").should("be.visible").click();

            });

      it("verify_check_availability_IS", () => {
           cy.wait(5000);
           cy.visit("/things-to-do/a.a166442.a");
           cy.wait(5000);
           cy.get("#check-availability-header > div > .uitk-type-300").click();
           cy.get(".uitk-date-picker-day-number.start").next().click();
           cy.get(".uitk-scrim > .uitk-button > .uitk-button-container").should("be.visible").click();

            });

      it("Verify_ISpage_TicketSelection", () => {
           const ticketCount = "\n2 Adults, \n1 Child\n";
           cy.wait(5000);
           cy.visit("/things-to-do/a.a166442.a");
           cy.wait(5000);
           cy.get("#check-availability-header > div > .uitk-type-300").click();
           cy.get(".uitk-date-picker-day-number.start").next().click();
           cy.get(".uitk-scrim > .uitk-button > .uitk-button-container").should("be.visible").click();
           cy.get(":nth-child(1) > a > .all-y-margin-four > .uitk-field").click();
           //cy.getElementsByClassName('uitk-step-input-button')[1].click();
           cy.get(".uitk-step-input-button").eq(1).click();
           cy.get(".uitk-step-input-button").eq(3).click();
           cy.get(".uitk-dialog-content > .uitk-button-large > .uitk-button-container").click();
           cy.get("#offer-list-block > :nth-child(1) > .uitk-button > .uitk-button-container").click();
           cy.wait(5000);
           cy.get(".flights").invoke("text").and("contain", "Review and book");
           cy.get(".lx-ticket-count").invoke("text").and("contain", ticketCount);

            });

      it("Verify_IS_Review_Section" , () => {
           const reviewScore = "/5";
           cy.visit("/things-to-do/a.a166597.a");
           cy.wait(5000);
           cy.get(".uitk-flex-justify-content-space-between > .uitk-type-400").and("contain", reviewScore);
           cy.get(":nth-child(1) > :nth-child(2) > .uitk-flex-justify-content-space-between > div > .uitk-link").click();
           cy.get("#user-comment-section > .uitk-type-heading-300").and("contain", "Sort reviews by");
           cy.get(".uitk-tab-text").eq(0).and("contain", "Recent").click();
           cy.get(".uitk-tab-text").eq(2).and("contain", "Critical").click();
           cy.get(".uitk-tab-text").eq(1).and("contain", "Positive").click();
           cy.get('.uitk-grid > :nth-child(1) > .uitk-button > .uitk-button-container > .uitk-icon > [aria-hidden="true"]').click();

        });

      });
