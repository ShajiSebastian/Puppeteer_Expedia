var variablesUsed = {
    "buttonSelector": 'button[data-stid="activities-destination-dialog-trigger',
    "dgfdfg" : "",
};

module.export = variablesUsed = variablesUsed;
