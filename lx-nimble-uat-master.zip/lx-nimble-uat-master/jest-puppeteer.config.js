module.exports = {
    exitOnPageError: false,
    launch: {
        headless: true,
        defaultViewport : null ,
        args: ["--no-sandbox", "--ignore-certificate-errors"],
        devtools: false,
    },
    args: [
      "--disable-background-timer-throttling",
      "--disable-backgrounding-occluded-windows",
      "--disable-renderer-backgrounding",
      ],
};
