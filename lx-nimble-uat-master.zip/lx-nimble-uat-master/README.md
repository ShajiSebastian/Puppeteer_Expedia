# lx-nimble-uat

#### How to run Tests ? 
Run https://ewegithub.sb.karmalab.net/EWE/lx-nimble project on local sandbox as per instructions

##### Clone the repo and run

1. ``npm install`` Install dependencies

2. ``yarn testdev`` Run tests 
