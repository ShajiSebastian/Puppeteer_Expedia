import basicConfig from '../../basic-config';
import { expected } from '../expectationFactory/expectationFactoryPwa';
import { infosite } from '../elementFactory/elementFactoryPwa';

// @ts-ignore
// tslint:disable-next-line:no-var-requires
const devices = require('puppeteer/DeviceDescriptors');
// @ts-ignore
export const iPhonex = devices['iPhone X'];
export const iPad = devices.iPad;

// const SRPurl = basicConfig.baseUrl;
// const logUrl = basicConfig.loginUrl;
//
// export const getSRPUrl = async function (location: any) {
//     return `${SRPurl}things-to-do/search?location=${location}`;
// };
//
// export const loginUrl = async function (email: any, pass: any) {
//     return `${logUrl}?email=${email}&password=${pass}`;
// };

// @ts-ignore
export const verifyLabel = async (selector: string, expectedText: string) => {
    await page.waitFor(selector);
    // @ts-ignore
    // tslint:disable-next-line:no-shadowed-variable
    const heading = await page.$eval(selector, (heading) => heading.textContent);
    expect(heading).toContain(expectedText);
};

export const matchLabel = async (selector: string, expectedText: string) => {
    await page.waitFor(selector);
    // @ts-ignore
    // tslint:disable-next-line:no-shadowed-variable
    const heading = await page.$eval(selector, (heading) => heading.textContent);
    expect(heading).toContainEqual(expectedText);
};

export const verifyFilterIsSelected = async (languageFilterCheckBoxSelector: string) => {
    await verifyFilterSelection(languageFilterCheckBoxSelector, true);
};

export const verifyFilterIsNotSelected = async (languageFilterCheckBoxSelector: string) => {
    await verifyFilterSelection(languageFilterCheckBoxSelector, false);
};

const verifyFilterSelection = async (languageFilterCheckBoxSelector: string, isSelected: boolean) => {
    const languageFilterFirstSelection = await page.$(languageFilterCheckBoxSelector);
    if (languageFilterFirstSelection) {
        if (isSelected) {
            expect(await (await languageFilterFirstSelection.getProperty('checked')).jsonValue()).toBeTruthy();
        } else {
            expect(await (await languageFilterFirstSelection.getProperty('checked')).jsonValue()).toBeFalsy();
        }
    }
};

export function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}

export const addDays = (days: any) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
};

export const getEndPoint = () => {
    if (process.env.NODE_ENV) {        
        switch (process.env.NODE_ENV) {
            case 'production':
                return 'https://www.expedia.com/';
            case 'dev':
                return 'https://wwwexpediacom.sandbox.dev.sb.karmalab.net:8080/';
            case 'test':
                return 'https://wwwexpediacom.trunk.sb.karmalab.net/';
            case 'DE':
                return 'https://wwwexpediade.trunk.sb.karmalab.net/';
            default:
                return 'https://wwwexpediacom.trunk.sb.karmalab.net/';
        }
     } 
};

export const getNewPageWhenLoaded = async () => {
    return new Promise((x) =>
        global.browser.on('targetcreated', async (target) => {
            if (target.type() === 'page') {
                const newPage = await target.page();
                const newPagePromise = new Promise((y) =>
                    newPage.once('domcontentloaded', () => y(newPage)),
                );
                const isPageLoaded = await newPage.evaluate(
                    () => document.readyState,
                );
                return isPageLoaded.match('complete|interactive')
                    ? x(newPage)
                    : x(newPagePromise);
            }
        }),
    );
};
