'use strict';
import {addDays, getEndPoint, getNewPageWhenLoaded, verifyLabel} from '../helpers/helper';

beforeAll(async () => {
    await page.goto(getEndPoint() + 'devtools/account/userlogout', {waitUntil: 'domcontentloaded'});
    await page.goto((getEndPoint() + 'tools/abacus/overrides?clean=1'), {waitUntil: 'load'});
    await page.reload({waitUntil: 'load'});
    await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=32715|1|1'), {waitUntil: 'load'});
    await page.goto((getEndPoint() + 'devtools/login?email=automationtest@expedia.com&password=test@123'), {waitUntil: 'load'});
});

describe.skip('Free LX Smoke Test Cases', () => {

    it ('Free LX Banner Test on HSRP', async () => {
        const startDate = addDays(1);
        const endDate = addDays(4);
        page.goto((getEndPoint() + 'Hotel-Search?adults=2&destination=Chicago%2C%20Illinois&endDate=' + endDate +
        '&rooms=1&sort=RECOMMENDED&startDate='
        + startDate), {waitUntil: 'domcontentloaded'});
        await page.waitForSelector('.uitk-cell.all-cell-1-2.all-cell-fill > div.messaging-card__title');
        const freeLXMessage = 'Explore Chicago (and vicinity) with a free activity.';
        const freeLXMessage_selecter = '.uitk-cell.all-cell-1-2.all-cell-fill > div.messaging-card__title';
        await verifyLabel(freeLXMessage_selecter, freeLXMessage);
        const moreDetails = 'More details';
        const moreDetails_selector = '.uitk-cell.all-cell-1-2.all-cell-fill > div.all-t-padding-two';
        await verifyLabel(moreDetails_selector, moreDetails);
    });

    it('Free LX Banner Test on Hotel IS Page', async () => {
        const startDate = addDays(1);
        const endDate = addDays(4);
        page.goto((getEndPoint() + 'Chicago-Hotels-Victorian-Rose-Garden.h3733857.Hotel-Information?chkin=' +
        startDate + '&chkout=' + endDate) , {waitUntil: 'domcontentloaded'});
        const freeLXMessage = 'Explore Algonquin with a free activity.';
        const freeLXMessage_selecter = '.uitk-cell.all-cell-1-2.all-cell-fill > div.messaging-card__title';
        await verifyLabel(freeLXMessage_selecter, freeLXMessage);
        const moreDetails = 'More details';
        const moreDetails_selector = '.uitk-cell.all-cell-1-2.all-cell-fill > div.all-t-padding-two';
        await verifyLabel(moreDetails_selector, moreDetails);
    });

    it('Free LX Banner Test on CKO Page', async () => {
        const startDate = addDays(1);
        const endDate = addDays(4);
        const freeLXMessage = 'Explore Chicago with a free activity';
        const freeLXMessage_selecter = 'h2.gift-activity-header';
        const secureBooking = 'Secure booking — only takes 2 minutes!';
        const secureBookingSelector = '#page-header > h1';
        page.goto((getEndPoint() + 'Chicago-Hotels-Victorian-Rose-Garden.h3733857.Hotel-Information?chkin=' +
        startDate + '&chkout=' + endDate) , {waitUntil: 'domcontentloaded'});
        await page.waitForSelector('button.uitk-button.uitk-button-small.uitk-button-primary.uitk-button-new-primary');
        page.click('button.uitk-button.uitk-button-small.uitk-button-primary.uitk-button-new-primary');
        page.waitForNavigation({waitUntil: 'load'});
        await verifyLabel(secureBookingSelector, secureBooking);
        await verifyLabel(freeLXMessage_selecter, freeLXMessage);
});

    it ('Verify Free LX Banner on CKO Confirmation page', async () => {
        await page.type('#stored_card_security_code' , '123', {delay: 4500});
        await page.click('input#no_insurance');
        await page.click('button.btn-primary.btn-action');
        await page.waitForNavigation({waitUntil: 'domcontentloaded'});
        const freeLXMessage = 'It\'s your lucky day!';
        const freeLXMessage_selecter = 'h2.gift-lx-header-message';
        await verifyLabel(freeLXMessage_selecter, freeLXMessage);
        const freeLXButton = 'Claim your free activity now';
        const freeLXButton_selector = 'a.btn';
        await verifyLabel(freeLXButton_selector, freeLXButton);
    });

    it ('Free Activities Test Cases when user is redirected to SRP from Hotels Confirmation Page', async () => {
        await page.waitFor('a.btn.btn-secondary.btn-sub-action');
        const newPagePromise = getNewPageWhenLoaded();
        await page.click('a.btn.btn-secondary.btn-sub-action');
        const newPage = await newPagePromise;
        await newPage.waitFor('h1#titleHeading');
        const checkBoxValue = await newPage.$eval('#categoryFilter0', (el) => el.checked ) ;
        expect(checkBoxValue).toBe(true);
        const url = await newPage.url();
        expect(url).toContain('categories=freeActivities');
        const freeActivitiesCategory_selector = 'span.expert-category.Recommendations';
        const heading = await newPage.$eval(freeActivitiesCategory_selector, (heading) => heading.textContent);
        expect(heading).toContain('Free activities');
        const freeActivitiesBanner_selector = '#free-lx-banner-decription';
        const heading1 = await newPage.$eval(freeActivitiesBanner_selector, (heading) => heading.textContent);
        expect(heading1).toContain('Pick a free activity');
    });

    it ('Free Activities Test Scenarios on LX SRP', async () => {
        const startDate = addDays(1);
        const endDate = addDays(4);
        await page.goto((getEndPoint() + 'things-to-do/search?location=Chicago&startDate=' + startDate + '&endDate=' + endDate)
        , {waitUntil: 'load'});
        await page.waitFor('h1#titleHeading');
        const freeActivitiesCategory_selector = 'span.expert-category.Recommendations';
        const categoryText =  await page.$eval(freeActivitiesCategory_selector, (a) => a.textContent);
        expect(categoryText).toContain('Free activities');
        await page.click('input#categoryFilter0.categoryFilter');
        await page.waitForSelector('#free-lx-banner-decription');
        const checkBoxValue = await page.$eval('#categoryFilter0', (el) => el.checked );
        expect(checkBoxValue).toBe(true);
        const url = await page.url();
        expect(url).toContain('categories=freeActivities');
        const freeActivitiesBanner_selector = '#free-lx-banner-decription';
        const freeActivitiesBanner = 'Pick a free activity';
        await verifyLabel(freeActivitiesBanner_selector, freeActivitiesBanner);
        const price_selector = 'strong#activityFromPrice193434:nth-child(2)';
        const price = '$0' ;
        await verifyLabel(price_selector, price);
        const ticketSize_selector = '.tile-price.prominence.tile-price-grey > #activityFromPriceTicketType193434:nth-child(3)';
        const ticketSize = 'for 1 adult only';
        await verifyLabel(ticketSize_selector, ticketSize);
    });

    it ('Free Activities Test Scenarios on  LX IS and CKO', async () => {
        const startDate = addDays(1);
        const endDate = addDays(4);
        await page.goto((getEndPoint() +
        'things-to-do/adler-planetarium.a193434.activity-details?location=Chicago+%28and+vicinity%29%2C+Illinois%2C+United+States+of+America&startDate='
        + startDate + '&endDate=' + endDate ), {waitUntil: 'load'});
        await page.waitFor('h1#activityTitle');
        const price_selector = 'strong#activityFromPrice';
        const price = '$0' ;
        await verifyLabel(price_selector, price);
        const ticketMessage_selector = 'span.freeLx-tooltip-text';
        const ticketMessage = 'You get this offer for free for 1 adult';
        await verifyLabel(ticketMessage_selector, ticketMessage);
        await page.click('button.btn-secondary.btn-sub-action.addActivity');
        await page.waitForNavigation({waitUntil: 'load'});
        const secureBooking = 'Secure booking — only takes 2 minutes!';
        const secureBookingSelector = '#page-header > h1';
        await verifyLabel(secureBookingSelector, secureBooking);
        const ckoTotalValue_selector = 'div.prod-total';
        const ckoTotalValue = '$0.00';
        await verifyLabel(ckoTotalValue_selector, ckoTotalValue);
    });

});
