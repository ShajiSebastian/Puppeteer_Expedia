'use strict';
import {getEndPoint, getNewPageWhenLoaded} from '../helpers/helper';

describe('Basic Regresion Test to Check Activity Lifecycle', () => {

    it('Activity Lifecycle Smoke on Legacy', async () => {
        await page.goto(getEndPoint(), {waitUntil: 'domcontentloaded'});
        await page.waitForSelector('.tabs-wrapper > .tabs > .tab > #tab-activity-tab-hp > .icons-container');
        await page.click('.tabs-wrapper > .tabs > .tab > #tab-activity-tab-hp > .icons-container');
        await page.waitForSelector('.col #activity-destination-hp-activity');
        await page.type('.col #activity-destination-hp-activity', ' Paris', {delay: 100});
        await page.keyboard.press('Enter', {delay: 1000});
        await page.keyboard.press('Enter', {delay: 1000});
        await page.waitForSelector('#activityResultsCtr > div > div > div.flex-content');
        const newPagePromise = getNewPageWhenLoaded();
        await page.click('#activityResultsCtr > div > div > div.flex-content');
        const newPage = await newPagePromise;
        await newPage.waitForSelector('.tile-price #offerAddButtonAtf');
        await newPage.waitFor(5000);
        await newPage.click('.tile-price #offerAddButtonAtf');
        await newPage.click('button.btn-secondary.btn-sub-action.addActivity');
        const pages = await browser.pages();
        const popup = pages[pages.length - 1];
        await popup.waitFor(5000);
        await popup.click('#createTrip > span');
        const secureBooking = 'Secure booking — only takes 2 minutes!';
        const secureBookingSelector = '#page-header > h1';
        await popup.waitFor(secureBookingSelector);
        const heading = await popup.$eval(secureBookingSelector, (heading) => heading.textContent);
        await expect(heading).toContain(secureBooking);
    });
});
