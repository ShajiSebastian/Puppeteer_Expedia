'use strict';
import { destinationPage, srp, infosite } from '../elementFactory/elementFactoryPwa';
import { getEndPoint, iPhonex, verifyFilterIsSelected, verifyLabel } from '../helpers/helper';
import { abacus, account, activityUrl } from '../urlFactory/urlFactoryPwa';
import { expected, loc } from '../expectationFactory/expectationFactoryPwa';

describe('LX PWA MIP Test in M0 view', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:32659|0|0:35083|1|1'), {waitUntil: 'load'});
        await page.goto(getEndPoint() + account.mipLogin, {waitUntil: 'load',});
        await page.emulate(iPhonex);
    });

    it('Verify MIP Badge, Banner, banner position in SRP and IS in M0 mode', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, {waitUntil: 'load'});
        var activityCount = await page.evaluate(() => {return document.querySelectorAll('a.uitk-card-link').length});
        while (await page.$(srp.badgeOfferText) === null && await page.$(srp.showMore) !== null  && activityCount < 100){
            await page.click(srp.showMore);
            await page.waitForFunction( `document.querySelectorAll('a.uitk-card-link').length > ${activityCount}`);
            await page.waitFor(3000);//This is required as it found that it takes some time load the entire actvities
            activityCount = await page.evaluate(() => {return document.querySelectorAll('a.uitk-card-link').length});
        }

        //Code to check whether mip badge is displayed or not
        await page.waitForSelector(srp.badgeOfferText);
        const m0Badgetexts = await page.evaluate(() => {
            const data = [];
            const elements = document.getElementsByClassName('uitk-badge-text');
            for (const element of elements) {
                data.push(element.textContent);
            }
            return data;
        });
        await expect(m0Badgetexts).toContain(expected().mipBadgeText);
        console.log('MIP Badge values for M0 mode:', m0Badgetexts);

        //Code to check whether mip banner is displayed or not
        const mipBannerTextSrp = await page.$eval(srp.mipBannerText, (el) => el.innerText);
        await expect(mipBannerTextSrp).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerTextSrp).toContain(expected().mipSrpOfferMessageText2);
        await expect(mipBannerTextSrp).not.toContain(' 0%');
        await expect(mipBannerTextSrp).not.toContain(' %');
        await expect(mipBannerTextSrp).toMatch(new RegExp('[0-99]%'));
        console.log('MIP Banner in M0 mode:',mipBannerTextSrp);

        //Code to check whether the position of MIP banner is just above the first MIP activity
        const title1 = await page.$x(`(//*[contains(text(),`+"'"+expected().mipBadgeText+"'"+`)]/preceding::h4)[last()]`);
        const mipBannerTextSrp2 = await page.evaluate(h1 => h1.textContent, title1[0]);
        await expect(mipBannerTextSrp2).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerTextSrp2).toContain(expected().mipSrpOfferMessageText2);
        console.log('MIP Banner position is correct in M0');

        //Code to check whether Infosite page is showing MIP banner, strickeout price, percentage of offer
        const mipBbadgeText = await page.$x(`//*[contains(text(),`+"'"+expected().mipBadgeText+"'"+`)]/ancestor::figure[1]`);
        await mipBbadgeText[0].click();
        await page.waitForSelector(infosite.mipBannerText);
        const mipBannerTextIs = await page.$eval(infosite.mipBannerText, (heading) => heading.textContent);
        console.log("MIP banner text in Infosite page:",mipBannerTextIs)
        await expect(mipBannerTextIs).toContain(expected().mipInfositeOfferMessageText1);
        await expect(mipBannerTextIs).toContain(expected().mipInfositeOfferMessageText2);
        await expect(mipBannerTextIs).toMatch(new RegExp('[0-99]%'));
        await page.waitForSelector(infosite.checkAvailibilitySecondDate);
        await page.click(infosite.checkAvailibilitySecondDate);
        await page.waitForSelector(infosite.nonDiscountedOfferPrice);
        const strikePrice = await page.$eval(infosite.nonDiscountedOfferPrice, (heading) => heading.textContent);
        await expect(strikePrice).toMatch(new RegExp('[0-9]*'));
        console.log('Strike out price for MIP activity:', strikePrice);
        const discountPercentage = await page.$eval(infosite.discountPercentage, (heading) => heading.textContent);
        await expect(discountPercentage).toMatch(new RegExp('[0-99]% '+expected().discountText));
        console.log('Discount percentage for MIP activity:', discountPercentage);
        console.log('Test PASS: Verify MIP Badge, Banner, banner position in SRP and IS in M0 mode in '+getEndPoint());
    });
});

describe('LX PWA MIP Test in M1 view', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:32659|1|1:35083|1|1'), {waitUntil: 'load'});
        await page.goto(getEndPoint() + account.mipLogin, {waitUntil: 'load'});
        await page.emulate(iPhonex);
    });

    it('MIP badge, banner text, banner position in Destinaion page and List vew in M1 mode', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, {waitUntil: 'load'});
        await page.waitForSelector(destinationPage.seeAllThingsToDo);

        //Code to check MIP badge in Destination view
        await page.waitForSelector(srp.badgeOfferText);
        const m1BadgeTexts = await page.evaluate(() => {
            const data = [];
            const elements = document.getElementsByClassName('uitk-badge-text');
            for (const element of elements) {
                data.push(element.textContent);

            }
            return data;
        });
        await expect(m1BadgeTexts).toContain(expected().mipBadgeText);
        console.log('MIP Badge values in Destination view M1 mode:', m1BadgeTexts);

        //Code to check MIP banner in Destination view
        const mipBannerDestinationView = await page.$eval(srp.mipBannerText, (el) => el.innerText);
        await expect(mipBannerDestinationView).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerDestinationView).toContain(expected().mipSrpOfferMessageText2);
        await expect(mipBannerDestinationView).not.toContain(' 0%');
        await expect(mipBannerDestinationView).not.toContain(' %');
        await expect(mipBannerDestinationView).toMatch(new RegExp('[0-99]%'));
        console.log('MIP Banner in Destination view M1 mode:',mipBannerDestinationView);

        //Code to check MIP banner position is just below of Top 10 things to do Carousel in Destination view
        await page.waitForSelector(srp.mipBannerText);
        const title3 = await page.$x(`(//*[contains(text(),`+"'"+expected().top10ThingsToDoHeader+"'"+`)])[1]//following::h4`);//(//*[contains(text(),'Top 10 things to do')])[1]//following::h4
        const mipBannerDestinationView2 = await page.evaluate(h1 => h1.textContent, title3[0]);
        await expect(mipBannerDestinationView2).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerDestinationView2).toContain(expected().mipSrpOfferMessageText2);
        const title4 = await page.$x(`((//*[contains(text(),`+"'"+expected().top10ThingsToDoHeader+"'"+`)])[1]/following::p)[1]`);//((//*[contains(text(),'Top 10 things to do')])[1]/following::p)[1]
        console.log('MIP Banner position is correct in M1 mode');

        //Code to check MIP badge in list view
        page.click(destinationPage.seeAllThingsToDo);
        await page.waitForFunction(() => document.querySelectorAll('.uitk-card-link').length > 40, {
            polling: 'mutation',
        }, {waitUntil: 'load'});
        if (await page.$(srp.showMore) !== null){
            await page.click(srp.showMore);
        await page.waitForFunction(() => document.querySelectorAll('[data-testid="activity-tile"]').length > 90, {
            polling: 'mutation',
            }, { waitUntil: 'load' });
        }
        if (await page.$(srp.showMore) !== null){
        await page.click(srp.showMore);}
        await page.waitFor(1000);// This is required as it takes some time to load next page
        await page.waitForSelector(srp.badgeOfferText);
        const listViewBbadgeTexts = await page.evaluate(() => {
            const data = [];
            const elements = document.getElementsByClassName('uitk-badge-text');
            for (const element of elements) {
                data.push(element.textContent);

            }
            return data;
        });
        await expect(listViewBbadgeTexts).toContain(expected().mipBadgeText);
        console.log('MIP Badge values for List view M1 mode:', listViewBbadgeTexts);

        //Code to check MIP banner in List view
        const mipBannerListView = await page.$eval(srp.mipBannerText, (el) => el.innerText);
        await expect(mipBannerListView).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerListView).toContain(expected().mipSrpOfferMessageText2);
        await expect(mipBannerListView).not.toContain(' 0%');
        await expect(mipBannerListView).not.toContain(' %');
        await expect(mipBannerListView).toMatch(new RegExp('[0-99]%'));
        console.log('MIP Banner in List view M1 mode:',mipBannerListView);

        //Code to check MIP Banner position is just above the first mip activity in List view
        const title1 = await page.$x(`(//*[contains(text(),`+"'"+expected().mipBadgeText+"'"+`)]/preceding::h4)[last()]`);
        const mipBannerTextSrp2 = await page.evaluate(h1 => h1.textContent, title1[0]);
        await expect(mipBannerTextSrp2).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerTextSrp2).toContain(expected().mipSrpOfferMessageText2);
        console.log('MIP Banner (postition test) in M1 mode:',mipBannerTextSrp2);
        console.log('Test PASS: MIP badge, banner text, banner position in Destinaion page and List vew in M1 mode in '+getEndPoint());
    });
});

describe('LX PWA MIP Test in M2 view', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:32659|1|1:33729|1|1:35083|1|1'), {waitUntil: 'load'});
        await page.goto(getEndPoint() + account.mipLogin, {waitUntil: 'load'});
        await page.emulate(iPhonex);   
              
    });

    it('MIP badge, banner, banner position test in Category and Subcategory page M2 mode', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, {waitUntil: 'load'});
        await page.waitForSelector(destinationPage.seeAllThingsToDo);
        await page.waitForSelector(destinationPage.browseByCategorySubcategoryTile1);
        await page.click(destinationPage.browseByCategorySubcategoryTile1);
        await page.waitForSelector(destinationPage.CategorySubcategoryPill)

        //Code to check MIP badge in category page
        await page.waitForSelector(srp.badgeOfferText);
        const categoryBadgeTexts = await page.evaluate(() => {
        const data = [];
        const elements = document.getElementsByClassName('uitk-badge-text');
        for (const element of elements) {
            data.push(element.textContent);
        }
        return data;
        });
        await expect(categoryBadgeTexts).toContain(expected().mipBadgeText);
        console.log('MIP Badge values in Category page in M2 mode:', categoryBadgeTexts);

        //code to check MIP Banner in category page
        const mipBannerCategoryPage = await page.$eval(srp.mipBannerText, (el) => el.innerText);
        await expect(mipBannerCategoryPage).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerCategoryPage).toContain(expected().mipSrpOfferMessageText2);
        await expect(mipBannerCategoryPage).not.toContain(' 0%');
        await expect(mipBannerCategoryPage).not.toContain(' %');
        await expect(mipBannerCategoryPage).toMatch(new RegExp('[0-99]%'));
        console.log('MIP Banner in Category page M2 mode:',mipBannerCategoryPage);

        //Code to check MIP banner position is just below of Top 10 things to do Carousel
        await page.waitForSelector(srp.mipBannerText);
        const title3 = await page.$x(`(//*[contains(text(),`+"'"+expected().browseByCaegoryHeader+"'"+`)]/preceding::h4)[last()]`);//(//*[contains(text(),'Top 10 things to do')])[1]//following::h4
        const mipBannerCategoryPage2 = await page.evaluate(h1 => h1.textContent, title3[0]);
        await expect(mipBannerCategoryPage2).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerCategoryPage2).toContain(expected().mipSrpOfferMessageText2);
        console.log('MIP Banner position is correct in Category page in M2 mode');

        //Code to check MIP badge in Subcategory page
        await page.waitForSelector(destinationPage.browseByCategorySubcategoryTile1);
        await page.waitFor(2000); // This is required as the new sub category pill has to be loaded. Else category name will read
        await page.click(destinationPage.browseByCategorySubcategoryTile1);
        await page.waitForSelector(destinationPage.CategorySubcategoryPill)
        await page.waitForSelector(srp.badgeOfferText);
        const SubCategoryBadgeTexts = await page.evaluate(() => {
        const data = [];
        const elements = document.getElementsByClassName('uitk-badge-text');
        for (const element of elements) {
            data.push(element.textContent);
        }
        return data;
        });
        await expect(SubCategoryBadgeTexts).toContain(expected().mipBadgeText);
        console.log('MIP Badge values in Subcategory page in M2 mode:', SubCategoryBadgeTexts);

        //Code to check MIP Banner in Subcategory page
        const mipBannerSubCategoryPage = await page.$eval(srp.mipBannerText, (el) => el.innerText);
        await expect(mipBannerSubCategoryPage).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerSubCategoryPage).toContain(expected().mipSrpOfferMessageText2);
        await expect(mipBannerSubCategoryPage).not.toContain(' 0%');
        await expect(mipBannerSubCategoryPage).not.toContain(' %');
        await expect(mipBannerSubCategoryPage).toMatch(new RegExp('[0-99]%'));
        console.log('MIP Banner in Subcategory page M2 mode:',mipBannerSubCategoryPage);

        //Code to check MIP Banner position is just above the first mip activity
        const title1 = await page.$x(`(//*[contains(text(),`+"'"+expected().br+"'"+`)]/preceding::h4)[last()]`);
        const mipBannerSubcategoryPage2 = await page.evaluate(h1 => h1.textContent, title1[0]);
        await expect(mipBannerSubcategoryPage2).toContain(expected().mipSrpOfferMessageText1);
        await expect(mipBannerSubcategoryPage2).toContain(expected().mipSrpOfferMessageText2);
        console.log('MIP Banner position is correct in Sub Category page in M2 mode');

        //Code to confirm MIP banner is same in both Category and Subcategory page
        await expect(mipBannerCategoryPage).toBe(mipBannerSubCategoryPage);
        console.log('MIP banner is same in Category and Subcategory page');
        console.log('Test PASS: MIP badge, banner, banner position test in Category and Subcategory page M2 mode in '+getEndPoint());
    });
});