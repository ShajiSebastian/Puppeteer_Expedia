'use strict';
import { infosite, cko } from '../elementFactory/elementFactoryPwa';
import { expected, loc } from '../expectationFactory/expectationFactoryPwa';
import { getEndPoint, iPhonex, verifyFilterIsNotSelected, verifyFilterIsSelected, verifyLabel } from '../helpers/helper';
import { abacus, account, activityUrl } from '../urlFactory/urlFactoryPwa';
export const selectCheckAavailabilityFutureDate = async () => {
    await page.waitForSelector(infosite.moreDatesLink);
    await page.click(infosite.moreDatesLink);
    await page.waitForSelector(infosite.pickAnyDateFromMoreDates);
    await page.click(infosite.pickAnyDateFromMoreDates);
    await page.click(infosite.dateModifySearchButton);
    await page.waitFor(3000);// This is required as it it takes some time to load new activities
}

describe('LX PWA IS page Test', () => {
    
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.reload({ waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=35083|1|1'), {waitUntil: 'load'});
        await page.emulate(iPhonex);
    });

    it('IS page design test', async () => {
        await page.goto(getEndPoint() + activityUrl.a234437, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector(infosite.activityTitle);
        await verifyLabel(infosite.activityTitle, expected().a234437ActivityName);
        await page.waitForSelector(infosite.locationText);
        await verifyLabel(infosite.locationText,expected().location);
        await page.waitForSelector(infosite.highlightText);
        await verifyLabel(infosite.highlightText,expected().highlightText);
        await page.waitForSelector(infosite.whatsIncludedText);
        await verifyLabel(infosite.whatsIncludedText,expected().whatsIncludedText);
        await page.waitForSelector(infosite.knowBeforeYouBook);
        await verifyLabel(infosite.knowBeforeYouBook,expected().knowBeforeYouBookText);
        await page.waitForSelector(infosite.checkAvailibility);
        await page.click(infosite.checkAvailibility);
        await verifyLabel(infosite.checkAvailibility, expected().checkAvailability);
        await page.waitForSelector(infosite.offerPrice);
        await verifyLabel(infosite.offerPrice, expected().currencySymbol);
        console.log('Test PASS: IS page design test in '+getEndPoint());
    });

    it.skip('Verify_IS_Review_Section', async () => {
        const review = 'review';
        const activityTitleSelecter = '#app > div > div.uitk-dialog-layer.uitk-dialog-layer-responsive.layer-overlay-active > div > div > header > section.uitk-cell.all-cell-fill > h2';
        const recentReviewSelecter = '#uitk-tabs-container > ul > li:nth-child(1) > a > span';
        const positiveReviewSelecter = '#uitk-tabs-container > ul > li:nth-child(2) > a > span';
        const criticalReviewSelecter = '#uitk-tabs-container > ul > li:nth-child(3) > a > span';
        await page.goto((getEndPoint() + url), { waitUntil: 'load' });
        await page.waitForSelector('div > .uitk-card > .uitk-flex-align-items-center > div > .uitk-link');
        await page.click('div > .uitk-card > .uitk-flex-align-items-center > div > .uitk-link');
        const reviewText = await page.evaluate((activityTitleSelecter) => {
            return document.querySelector(activityTitleSelecter).innerHTML;
        }, activityTitleSelecter);
        await expect(reviewText).toContain(review);
        await verifyLabel(recentReviewSelecter, 'Recent');
        await verifyLabel(positiveReviewSelecter, 'Positive');
        await verifyLabel(criticalReviewSelecter, 'Critical');
    });

    it('Verify 3 Recommnded activities are visible or not', async () => {
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=32506|0|0');
        await page.goto((getEndPoint() + activityUrl.a171360), { waitUntil: 'load' });
        await page.waitForSelector(infosite.recommendedActivitiesHeader);
        await page.waitForSelector(infosite.thirdRecommendation, { visible: true });
        const RecommendedActivitiesHeader = await page.$eval(infosite.recommendedActivitiesHeader, (heading) => heading.textContent);
        console.log('Other Recommended activities header:',RecommendedActivitiesHeader);
        await (verifyLabel(infosite.recommendedActivitiesHeader, expected().otherRecommendedActivitiesHeaderText) || verifyLabel(infosite.recommendedActivitiesHeader, expected().otherRecommendedActivitiesHeaderText));
        const otherRecommendedActivitiesTileCount = (await page.$$(infosite.recommendedActivitiesTiles)).length;
        await expect(otherRecommendedActivitiesTileCount).toBe(3);
        console.log('Number of activities in Recommended activities section:',otherRecommendedActivitiesTileCount);
        console.log('Test PASS: Verify 3 Recommnded activities are visible or not in '+getEndPoint());
    });

    it('Passenger count selection in IS', async () => {
        await page.goto((getEndPoint() + 'things-to-do/a.a415235.a'), { waitUntil: 'load' });
        await page.waitForSelector(infosite.checkAvailabilityStickyBar);
        await page.click(infosite.checkAvailabilityStickyBar);
        await selectCheckAavailabilityFutureDate();
        await page.waitForSelector(infosite.travelersCount);
        await verifyLabel(infosite.travelersCount, expected().defaultPaxCountIsPage);
        await page.click(infosite.travelersCount);
        await page.waitForSelector(infosite.adultCount);
        await page.click(infosite.adultCount);
        await page.waitFor(500); // This is required as the script clicks on same button two times quickly
        await page.click(infosite.adultCount);
        await page.click(infosite.childCount);
        await page.waitFor(500); // This is required as the script clicks on same button two times quickly
        await page.click(infosite.childCount);
        await page.click(infosite.infantCount);
        await page.waitFor(500); // This is required as it takes sometimes to reflect the change
        await verifyLabel(infosite.paxSelectorPaxPopup, expected().paxSelectorPaxPopupText);
        await page.click(infosite.doneButtonPaxPopup);
        await page.waitFor(1000); // This is required as it takes sometimes to reflect the change
        await verifyLabel(infosite.travelersCount, expected().paxSelectorPaxPopupText);
        const travellersCount = await page.$eval(infosite.travelersCount, (heading) => heading.textContent);
        console.log('Travellers:',travellersCount);
        console.log('Test PASS: Passenger count selection in IS in '+getEndPoint());
    });

    it('Verify otherecommendation list has 6 activities when ab 32506 on', async () => {
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=32506|1|1');
        await page.goto((getEndPoint() + activityUrl.a171360), { waitUntil: 'load' });
        await page.waitForSelector(infosite.recommendedActivitiesHeader);
        await page.waitForSelector(infosite.recommendedActivitiesTiles);
        await page.waitForSelector(infosite.sixthRecommendation);
        const otherRecommendedActivitiesTileCount = (await page.$$(infosite.recommendedActivitiesTiles)).length;
        await expect(otherRecommendedActivitiesTileCount).toBe(6);
        await page.click(infosite.firstRecommendation);
        const checkUrlforfirst = await page.evaluate(() => location.href);
        await expect(checkUrlforfirst).toContain('LX.IS.Recommend.1');
        console.log('Number of activities in Recommended activities section when ab 32506 on:',otherRecommendedActivitiesTileCount);
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=32506|0|0');
        console.log('Test PASS: Verify otherecommendation list has 6 activities when ab 32506 on in '+getEndPoint());
    });

    it('Should show activity price on date buttons when ab 33728 is ON', async () => {
        //This functionality is available only for US pos
        if (process.env.NODE_ENV?.includes("test")){
        await page.goto(getEndPoint() + '/tools/abacus/overrides?abov=33728|1|1', { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + activityUrl.a234437), { waitUntil: 'load' });
        await selectCheckAavailabilityFutureDate();
        await verifyLabel(infosite.dateButtonPrice, expected().currencySymbol);
        const priceAmount = await page.$eval(infosite.dateButtonPrice, (el) => el.innerText);
        console.log('Price: ', priceAmount);
        await expect(priceAmount).toContain(expected().currencySymbol);
        await expect(priceAmount).not.toContain(expected().currencySymbol + ' ');
        await expect(priceAmount).not.toContain('  ' + expected().currencySymbol);
        await expect(priceAmount).toMatch(new RegExp( '[1-9]*'));
        const Pricelist = await page.$$eval(infosite.dateButtonPrice, (ele) => ele.map((elem) => elem.textContent).slice(0, 10));
        await expect(Pricelist).not.toBeNull();
        await expect(Pricelist).not.toContain(0);
        await expect(Pricelist).not.toContain(expected().currencySymbol + 0);
        await expect(Pricelist).not.toContain(0 + ' ' + expected().currencySymbol);
        console.log('Date button prices list with currency when ab 33728 in ON:', Pricelist);
        await page.goto(getEndPoint() + '/tools/abacus/overrides?abov=33728|0|0', { waitUntil: 'domcontentloaded' });
        console.log('Test PASS: Should show activity price on date buttons when ab 33728 is ON in '+getEndPoint()); 
        }
        else {
        console.log('Test PASS: Should show activity price on date buttons when ab 33728 is ON functionality is not available in '+getEndPoint());  
        }
    });

    it('should display next available date banner when ab 32507 is ON', async () => {
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=32507|1|1'), { waitUntil: 'load' });
        const activityUrl = getEndPoint() +
            'things-to-do/hollywood-vip-day-tour-from-las-vegas.a182995.activity-details?endDate=2020-06-23&expandedRegion=false&location=los%20angeles&pageNumber=1&srp=true&startDate=2020-06-23';
        await page.goto(activityUrl, { waitUntil: 'load' });
        await verifyLabel(infosite.nextAvailableDateHeaderSelector, expected().nextAvailableDateHeaderText);
        await verifyLabel(infosite.nextAvailableDateSubHeaderSelector, expected().nextAvailableDateSubHeaderText);
        await verifyLabel(infosite.nextAvailableDateLinkSelector, expected().nextAvailableDateLinkText);
        const nextAvailableDateHeaderText = await page.$eval(infosite.nextAvailableDateHeaderSelector, (heading) => heading.textContent);
        console.log('Next Available Date HeaderText when ab 32507 is ON:',nextAvailableDateHeaderText);
        await page.goto(getEndPoint() + '/tools/abacus/overrides?abov=33728|0|0', { waitUntil: 'domcontentloaded' });
        console.log('Test PASS: should display next available date banner when ab 32507 is ON in '+getEndPoint());
    });

    it('should display inventory error banner when ab 32507 is OFF', async () => {
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=32507|0|0'), { waitUntil: 'load' });
        const activityUrl = getEndPoint() +
            'things-to-do/hollywood-vip-day-tour-from-las-vegas.a182995.activity-details?endDate=2020-06-23&expandedRegion=false&location=los%20angeles&pageNumber=1&srp=true&startDate=2020-06-23';
        await page.goto(activityUrl, { waitUntil: 'load' });
        await verifyLabel(infosite.inventoryErrorHeaderSelector, expected().inventoryErrorHeader);
        const inventoryErrorHeader = await page.$eval(infosite.inventoryErrorHeaderSelector, (heading) => heading.textContent);
        console.log('Inventory Error when ab 32507 is OFF:',inventoryErrorHeader);
        console.log('Test PASS: should display inventory error banner when ab 32507 is OFF in '+getEndPoint());
    });

    it('display collapsible text sections for Description of activity', async () => {
        await page.goto((getEndPoint() + activityUrl.a171360), { waitUntil: 'load' });
        if (await page.$(infosite.descriptionSeeMore) !== null) {
            await verifyLabel(infosite.descriptionSeeMore, expected().seeMore);
            await page.click(infosite.descriptionSeeMore);
            await verifyLabel(infosite.descriptionSeeMore, expected().seeLess);
            await page.click(infosite.descriptionSeeMore);
            await verifyLabel(infosite.descriptionSeeMore, expected().seeMore);
            console.log('See more and See less functionality works fine for description in IS page')
            console.log('Test PASS: display collapsible text sections for Description of activity in '+getEndPoint());
        } else {
            console.log('see more link for Description of activity is an optonal field');
            console.log('Test PASS: display collapsible text sections for Description of activity in '+getEndPoint());
        }
    });
});

describe.skip('Expedia IS page test meal inclusion filters', () => {

    const activityUrl = getEndPoint() + 'things-to-do/deluxe-champagne-tour.a277625.activity-details?categories=FoodDrinkNightlife&endDate=2019-11-27&expandedRegion=false&location=Los%20Angeles%2C%20California&pageNumber=1&sortBy=ExpediaPicks&srp=true&startDate=2019-11-13';
    const setABUrl = getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:31970|1|1|:32194|1|1|:32200|1|1:32194|1|1:35083|1|1';
    const mealInclusionOptions = '#mealInclusion';
    const mealInclusionFilterHeader = 'Meal inclusions';
    const mealInclusionFilterLabel = 'Drinks Only';
    const mealInclusionFilterHeaderSelector = '#mealInclusion-header';
    const mealInclusionFilterLabelSelector = '#mealInclusion-body > div:nth-child(1)';
    const mealInclusionFilterCheckBoxSelector = '#mealInclusion-body > div:nth-child(1) > input';
    const visibilityOptions = { visible: true };

    beforeAll(async () => {
        await page.goto(getEndPoint() + 'devtools/account/userlogout', { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?clean=1'), { waitUntil: 'load' });
        await page.reload({ waitUntil: 'load' });
        await page.emulate(iPhonex);
    });

    // The following script always fails
    it.skip('shouldnot display meal inclusion filters when ab is OFF', async () => {
        await page.goto(setABUrl + '33050|0|0');
        await page.goto(activityUrl);
        await page.waitForSelector(mealInclusionOptions).catch((error) => {
            expect(error.message).toBe('waiting for selector "#mealInclusion" failed: timeout 10001ms exceeded');
        });
    });

    // Need to recheck once above and below scripts are corrected
    it.skip('should display non selected first meal inclusion filter when ab is ON', async () => {
        await page.goto(setABUrl + '33050|1|1');
        await page.goto(activityUrl);
        await verifyLabel(mealInclusionFilterHeaderSelector, mealInclusionFilterHeader);
        await verifyLabel(mealInclusionFilterLabelSelector, mealInclusionFilterLabel);
        await verifyFilterIsNotSelected(mealInclusionFilterCheckBoxSelector);
    });

    // The script marked as PASS for {visible: false};
    it.skip('should be able to select other meal inclusion filter with ab is ON', async () => {
        await page.goto(setABUrl + '33050|1|1');
        await page.goto(activityUrl);
        await verifyLabel(mealInclusionFilterHeaderSelector, mealInclusionFilterHeader);
        await verifyLabel(mealInclusionFilterLabelSelector, mealInclusionFilterLabel);
        // By default no filters are selected
        await verifyFilterIsNotSelected(mealInclusionFilterCheckBoxSelector);
        await page.click(mealInclusionFilterLabelSelector);
        await page.waitForSelector(mealInclusionOptions, visibilityOptions);
        // Verify filter is selected after click
        await verifyLabel(mealInclusionFilterLabelSelector, mealInclusionFilterLabel);
        await verifyFilterIsSelected(mealInclusionFilterCheckBoxSelector);
    });
});

describe('LX_IS_Redesign_Tests', () => {

    const setABUrl = getEndPoint() + 'tools/abacus/overrides?abov=34960|1|1:';
    const activityUrl = getEndPoint() + 'things-to-do/a.a415235.a';
    const unvailableActivityUrl = getEndPoint() +
            'things-to-do/hollywood-vip-day-tour-from-las-vegas.a182995.activity-details?endDate=2020-06-23&expandedRegion=false&location=los%20angeles&pageNumber=1&srp=true&startDate=2020-06-23';

    const isElementVisible = async (page, cssSelector) => {
        let visible = true;
        await page.waitForSelector(cssSelector, { visible: true, timeout: 5000 })
        .catch(() => {
            visible = false;
        });
        return visible;
    };

    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=34960|1|1');
        await page.reload({ waitUntil: 'load' });
        await page.emulate(iPhonex);
    });

    it('New heirarchy of elements with ab 34960', async () => {
        await page.goto((activityUrl), { waitUntil: 'load' });
        const isAvailabilityModuleVisible = await isElementVisible(page, infosite.checkAvailibilityDates);
        expect(isAvailabilityModuleVisible).toBe(true);
        const isSeeTicketsBannerVisible = await isElementVisible(page, infosite.seeTicketsBannerButton);
        expect(isSeeTicketsBannerVisible).toBe(false);
        var isOfferListVisible = await isElementVisible(page, infosite.offerListBlock);
        expect(isOfferListVisible).toBe(false);
        const isSeeTicketsButtonAvialable = await isElementVisible(page, infosite.seeTicketsStickyButton);
        expect(isSeeTicketsButtonAvialable).toBe(true);
        await page.click(infosite.seeTicketsStickyButton);
        isOfferListVisible = await isElementVisible(page, infosite.offerListBlock);
        expect(isOfferListVisible).toBe(true);
        console.log('Test PASS: New heirarchy of elements with ab 34960 in '+getEndPoint());
    });
    
    it('Display next available date banner when ab 32507 is ON On IS page', async () => {
        await page.goto(setABUrl + '32507|1|1');
        await page.goto(unvailableActivityUrl, { waitUntil: 'load' });
        await verifyLabel(infosite.nextAvailableDateHeaderSelector, expected().nextAvailableDateHeaderText);
        await verifyLabel(infosite.nextAvailableDateSubHeaderSelector, expected().nextAvailableDateSubHeaderText);
        await verifyLabel(infosite.nextAvailableDateLinkSelector, expected().nextAvailableDateLinkText);
        await page.goto(setABUrl + '32507|0|0');
        console.log('Test PASS: Display next available date banner when ab 32507 is ON On IS page in '+getEndPoint());
    });
    
    it('Display inventory error banner when ab 32507 is OFF', async () => {
        await page.goto(setABUrl + '32507|0|0');
        await page.goto(unvailableActivityUrl, { waitUntil: 'load' });
        await verifyLabel(infosite.inventoryErrorHeaderSelector, expected().inventoryErrorHeader);
        console.log('Test PASS: Display inventory error banner when ab 32507 is OFF in '+getEndPoint());
    });

    it('Passenger count selection on offers dialog', async () => {
        await page.goto((getEndPoint() + 'things-to-do/a.a415235.a'), { waitUntil: 'load' });
        await selectCheckAavailabilityFutureDate();
        const isSeeTicketsButtonAvialable = await isElementVisible(page, infosite.seeTicketsStickyButton);
        expect(isSeeTicketsButtonAvialable).toBe(true);
        await page.click(infosite.seeTicketsStickyButton); // open offers dialog
        const isOfferListVisible = await isElementVisible(page, infosite.offerListBlock);
        expect(isOfferListVisible).toBe(true); 
        
        await page.waitForSelector(infosite.travelersCount);
        await verifyLabel(infosite.travelersCount, expected().defaultPaxCountIsPage);        
        await page.click(infosite.travelersCount); // open ticket selection dialog

        await page.waitForSelector(infosite.adultCount);
        await page.click(infosite.adultCount);
        await page.waitFor(500); // This is required as the script clicks on same button two times quickly
        await page.click(infosite.adultCount);
        await page.click(infosite.childCount);
        await page.waitFor(500); // This is required as the script clicks on same button two times quickly
        await page.click(infosite.childCount);
        await page.click(infosite.infantCount);
        await page.waitFor(500); // This is required as it takes sometimes to reflect the change
        await verifyLabel(infosite.paxSelectorPaxPopup, expected().paxSelectorPaxPopupText);
        await page.click(infosite.doneButtonPaxPopup);
        await page.waitFor(1000); // This is required as it takes sometimes to reflect the change
        await verifyLabel(infosite.travelersCount, expected().paxSelectorPaxPopupText);
        const travellersCount = await page.$eval(infosite.travelersCount, (heading) => heading.textContent);
        console.log('Travellers:',travellersCount);
        console.log('Test PASS: Passenger count selection on offers dialog in '+getEndPoint());
    });

    it('Should display header of language and time filter when ab 33050 is ON', async () => {
        await page.goto(setABUrl + '33050|1|1',{ waitUntil: 'load' });
        await page.goto(getEndPoint() + 'things-to-do/a.a522315.a', { waitUntil: 'load' });
        await page.waitForSelector(infosite.seeTicketsStickyButton);
        await page.click(infosite.seeTicketsStickyButton);

        //Code to check Language options
        await page.waitForSelector(infosite.languageOptions);
        await verifyLabel(infosite.languageFilterHeaderSelector, expected().languageFilterHeader);
        await verifyLabel(infosite.languageFilterLabelSelector, expected().languageFilterLabel);
        await verifyFilterIsSelected(infosite.enLanguageFilterCheckBoxSelector);
        const offerCountEng = await page.evaluate(() => {return document.querySelectorAll('button.uitk-button.uitk-button-large.uitk-button-fullWidth.uitk-button-primary').length;});
        console.log('Offer count in First available Language:',offerCountEng)
        await page.waitForSelector(infosite.deLanguageFilterLabelSelector)
        await page.click(infosite.deLanguageFilterLabelSelector);
        await page.waitFor(1000); //This is required as it takes some time to get it selected
        await page.waitForSelector(infosite.languageOptions);
        await verifyLabel(infosite.deLanguageFilterLabelSelector, expected().germanFilterLabel);
        await verifyFilterIsSelected(infosite.deLanguageFilterCheckBoxSelector);
        const offerCountGerman = await page.evaluate(() => {return document.querySelectorAll('button.uitk-button.uitk-button-large.uitk-button-fullWidth.uitk-button-primary').length;});
        console.log('Offer count in second available Language:',offerCountGerman);
        await expect(offerCountEng).toBe(offerCountGerman);

        //Code to check time options
        await page.waitForSelector(infosite.timeOptions);
        await verifyLabel(infosite.timeOptionHeaderSelector, expected().timeFilterHeader);
        await page.waitForSelector(infosite.timeFilterLabelSelectorSecond)
        await page.click(infosite.timeFilterLabelSelectorSecond);
        await page.waitFor(1000); //This is required as it takes some time to get it selected
        await page.waitForSelector(infosite.timeOptions);
        await verifyFilterIsSelected(infosite.timeFilterCheckBoxSelectorSecond);
        const offerCountSecondTime = await page.evaluate(() => {return document.querySelectorAll('button.uitk-button.uitk-button-large.uitk-button-fullWidth.uitk-button-primary').length;});
        console.log('Offer count for second available time:',offerCountSecondTime);
        await expect(offerCountSecondTime).toBeGreaterThanOrEqual(1);
        await page.goto(setABUrl + '33050|0|0');
        console.log('Test PASS: Should display header of language and time filter when ab 33050 is ON in '+getEndPoint());
    });
    
    it.skip('verify see tickets button leads to payment page with ab 34960', async () => {
        await page.goto(activityUrl);
        await page.waitForSelector(infosite.seeTicketsStickyButton);
        await page.click(infosite.seeTicketsStickyButton);
        await page.waitForSelector(infosite.bookButton);
        await page.click(infosite.bookButton);
        await verifyLabel(cko.secureBookingText, expected().ckoSecureBookingText);
    });

    it('should display tab navigation bar with all the tabs with ab 34960', async () => {
        await page.goto((activityUrl), { waitUntil: 'load' });
        var isTabNavigationBarVisible = await isElementVisible(page, infosite.tabNavigationBarMiddle);
        expect(isTabNavigationBarVisible).toBe(true);
        await isElementVisible(page, infosite.recommendedActivitiesHeader);
        await isElementVisible(page, infosite.reviewComments);

        await verifyLabel(infosite.firstNavigationTab, expected().highlightsTabLabel);
        await verifyLabel(infosite.secondNavigationTab, expected().moreInfoTabLabel);
        await verifyLabel(infosite.thirdNavigationTab, expected().locationTabLabel);
        await verifyLabel(infosite.fourthNavigationTab, expected().reviewsTabLabel);
        await page.click(infosite.firstNavigationTab);
        await page.waitFor(600); //wating for page to scroll down to highlights section
        const amenityCarouselModule = await page.$(infosite.amenityCarousel);
        var isAmenityCarouselModuleVisible = await amenityCarouselModule?.isIntersectingViewport()
        expect(isAmenityCarouselModuleVisible).toBe(false);
        
        await page.click(infosite.thirdNavigationTab);
        await page.waitFor(600); //wating for page to scroll down to location section
        var activityLocationModule = await page.$(infosite.activityLocation);
        var isActivityLocationModule = await activityLocationModule?.isIntersectingViewport()
        expect(isActivityLocationModule).toBe(true);
        var classNames = await page.$(infosite.thirdNavigationTab)
                .then((el) => el?.getProperty("className"))
                .then((cn) => cn?.jsonValue())    
                .then((classNameString) => classNameString.split(" "));
        expect(classNames).toContain('active');

        //checking if the scroll position persists on page refresh
        await page.reload({ waitUntil: 'load' });
        await isElementVisible(page, infosite.tabNavigationBarMiddle);
        await page.waitFor(800); //wating for page to scroll
        activityLocationModule = await page.$(infosite.activityLocation);
        isActivityLocationModule = await activityLocationModule?.isIntersectingViewport()
        expect(isActivityLocationModule).toBe(true);
        await isElementVisible(page, infosite.recommendedActivitiesHeader);
        await isElementVisible(page, infosite.reviewComments);
        
        await page.click(infosite.fourthNavigationTab);
        await page.waitFor(600); //wating for page to scroll down to reviews section
        activityLocationModule = await page.$(infosite.activityLocation);
        isActivityLocationModule = await activityLocationModule?.isIntersectingViewport()
        expect(isActivityLocationModule).toBe(false);
        classNames = await page.$(infosite.fourthNavigationTab)
                .then((el) => el?.getProperty("className"))
                .then((cn) => cn?.jsonValue())    
                .then((classNameString) => classNameString.split(" "));
        expect(classNames).toContain('active');
        console.log('Test PASS: should display tab navigation bar with all the tabs with ab 34960 in '+getEndPoint());
    });

    it('should display review section on page when AB 34960 is on', async () => {
        await page.goto((activityUrl), { waitUntil: 'load' });
        await isElementVisible(page, infosite.recommendedActivitiesHeader);
        await isElementVisible(page, infosite.reviewsSection);

        //code to check review section is just below of Recommended activities section
        const reviewSectionElement = await page.$(infosite.reviewsSection);
        const previousElement = await page.evaluateHandle(el => el.previousElementSibling, reviewSectionElement);
        const previousElementId = await page.evaluate(el => el.getAttribute('data-testid'), previousElement);
        expect(previousElementId).toBe('recommendation-list');

        //code to check review section
        await verifyLabel(infosite.reviewRating, expected().reviewRatingText);
        const reviewsSortTabsLength = (await page.$$(infosite.reviewsSortTabs)).length;
        expect(reviewsSortTabsLength).toBe(3);
        await verifyLabel(infosite.reviewsRecentSortTab, expected().reviewsRecentSortLabel);
        await verifyLabel(infosite.reviewsPositiveSortTab, expected().reviewsPositiveSortLabel);
        await verifyLabel(infosite.reviewsCriticalSortTab, expected().reviewsCriticalSortLabel);
        console.log('Reviews can be sorted by:',expected().reviewsRecentSortLabel,expected().reviewsPositiveSortLabel,expected().reviewsCriticalSortLabel);
        var classNames = await page.$(infosite.reviewsRecentSortTab)
                .then((el) => el?.getProperty("className"))
                .then((cn) => cn?.jsonValue())    
                .then((classNameString) => classNameString.split(" "));
        expect(classNames).toContain('active');
        await isElementVisible(page, infosite.reviewComments);
        const reviewCommentsLength = (await page.$$(infosite.reviewComments)).length;
        expect(reviewCommentsLength).toBe(5);
        console.log('Number of default review comments:',reviewCommentsLength);
        await verifyLabel(infosite.firstReviewCommentHeader,"/5");

        //code for sorting of reviews
        await page.click(infosite.reviewsCriticalSortTab);
        await isElementVisible(page, infosite.reviewComments);
        await verifyLabel(infosite.firstReviewCommentHeader,"/5");
        classNames = await page.$(infosite.reviewsCriticalSortTab)
                .then((el) => el?.getProperty("className"))
                .then((cn) => cn?.jsonValue())    
                .then((classNameString) => classNameString.split(" "));
        expect(classNames).toContain('active');

        //code to check all reviews
        await verifyLabel(infosite.reviewsSectionButton, expected().reviewsSectionCTAButtonLabel);
        var reviewsDialog = await isElementVisible(page, infosite.reviewSectionDialog);
        expect(reviewsDialog).toBe(false);
        await page.click(infosite.reviewsSectionButton);
        reviewsDialog = await isElementVisible(page, infosite.reviewSectionDialog);
        expect(reviewsDialog).toBe(true);
        await verifyLabel(infosite.reviewSectionDialogHeader, expected().reviewDialogHeaderText);
        const allReviewCommentsLength = (await page.$$(infosite.reviewComments)).length;
        expect(reviewCommentsLength).toBe(5);
        console.log('Number of all review comments:',allReviewCommentsLength);
        console.log('Test PASS: should display review section on page when AB 34960 is on in '+getEndPoint());
    });

    it('should display new amenity carousel on page when AB 34960 is on', async () => {
        await page.goto((activityUrl), { waitUntil: 'load' });
        const isAmenityCarouselModuleVisible = await isElementVisible(page, infosite.amenityCarousel);
        expect(isAmenityCarouselModuleVisible).toBe(true);
        
        const totalAmenitiesIconsPresent = (await page.$$(infosite.amenityCarouselIcon)).length;
        expect(totalAmenitiesIconsPresent).toBe(6);
        await verifyLabel(infosite.thirdAmenityCarouselIcon,expected().thirdAmenityCarouselText);
        await verifyLabel(infosite.fourthAmenityCarouselIcon,expected().fourthAmenityCarouselText);
        console.log('Test PASS: should display new amenity carousel on page when AB 34960 is on in '+getEndPoint());
    });

    it('should display new offer feature carousel on offer section when AB 34960 is on', async () => {
        await page.goto((activityUrl), { waitUntil: 'load' });
        await selectCheckAavailabilityFutureDate();
        const isSeeTicketsButtonAvialable = await isElementVisible(page, infosite.seeTicketsStickyButton);
        expect(isSeeTicketsButtonAvialable).toBe(true);
        await page.click(infosite.seeTicketsStickyButton);
        const isOfferListVisible = await isElementVisible(page, infosite.offerListBlock);
        expect(isOfferListVisible).toBe(true);
        const isOfferFeatureCarouselVisible = await isElementVisible(page, infosite.offerFeatureCarouselList);
        expect(isOfferFeatureCarouselVisible).toBe(true);
        const totalFeaturesCarouselList = (await page.$$(infosite.offerFeatureCarouselList)).length;
        const offersAvailalbe = (await page.$$(infosite.offerCount)).length;
        expect(offersAvailalbe).toBeGreaterThanOrEqual(1);
        console.log('Number of offer activites:',offersAvailalbe);
        const totalFeaturesIconsPresent = (await page.$$(infosite.offerFeatureCarouselIcons)).length;
        expect(totalFeaturesIconsPresent).toBeGreaterThanOrEqual(1);
        console.log('Number of offer feature icons:',totalFeaturesIconsPresent);
        await expect(totalFeaturesCarouselList).toBe(offersAvailalbe);
        console.log('Test PASS: should display new offer feature carousel on offer section when AB 34960 is on in '+getEndPoint());
    });

    it('should display updated navigation tabs and bar position when both AB 34960 and AB 35941 are on', async() => {
        await page.goto(setABUrl + '35941|1|1');
        await page.goto((activityUrl), { waitUntil: 'load' });
        var isTabNavigationBarVisible = await isElementVisible(page, infosite.tabNavigationBarTop);
        expect(isTabNavigationBarVisible).toBe(true);
        await isElementVisible(page, infosite.recommendedActivitiesHeader);
        await isElementVisible(page, infosite.reviewComments);

        await verifyLabel(infosite.firstNavigationTab, expected().overviewTabLabel);
        await verifyLabel(infosite.secondNavigationTab, expected().highlightsTabLabel);
        await verifyLabel(infosite.thirdNavigationTab, expected().detailsTabLabel);
        await verifyLabel(infosite.fourthNavigationTab, expected().locationTabLabel);
        await verifyLabel(infosite.fifthNavigationTab, expected().reviewsTabLabel);
        await page.goto(setABUrl + '35941|0|0');
        console.log('Test PASS: should display updated navigation tabs and bar position when both AB 34960 and AB 35941 are on in '+getEndPoint());
    })

    it('should not display see tickets banner and see tickets sticky together when both AB 34960 and AB 35941 are on', async() => {
        await page.goto(setABUrl + '35941|1|1');
        await page.goto((activityUrl), { waitUntil: 'load' });

        var isSeeTicketsBannerVisible = await isElementVisible(page, infosite.seeTicketsBannerButton);
        expect(isSeeTicketsBannerVisible).toBe(true);

        await page.evaluate((selector) => {
            const element = document.querySelector(selector);
            element?.scrollIntoView(false);
        }, infosite.seeTicketsBannerButton);

        await page.waitFor(600); //wating for page to scroll down to location section
        isSeeTicketsBannerVisible = await isElementVisible(page, infosite.seeTicketsBannerButton);
        expect(isSeeTicketsBannerVisible).toBe(true);
        const isSeeTicketsStickyButtonAvialable = await isElementVisible(page, infosite.seeTicketsStickyButton);
        expect(isSeeTicketsStickyButtonAvialable).toBe(false);

        await page.click(infosite.seeTicketsBannerButton);
        const isOfferListVisible = await isElementVisible(page, infosite.offerListBlock);
        expect(isOfferListVisible).toBe(true);
        await page.goto(setABUrl + '35941|0|0');
        console.log('Test PASS: should not display see tickets banner and see tickets sticky together when both AB 34960 and AB 35941 are on in '+getEndPoint());
    })

});
