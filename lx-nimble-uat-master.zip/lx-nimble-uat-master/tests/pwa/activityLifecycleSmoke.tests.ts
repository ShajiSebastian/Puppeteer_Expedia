'use strict';
import { cko, destinationPage, infosite, srp, storeFront } from '../elementFactory/elementFactoryPwa';
import { expected } from '../expectationFactory/expectationFactoryPwa';
import { getEndPoint, iPad, iPhonex, verifyLabel } from '../helpers/helper';
import { abacus, account } from '../urlFactory/urlFactoryPwa';

describe('Basic Regresion Test to Check Activity Lifecycle', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto(getEndPoint() + abacus.abClean, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=35083|1|1'), {waitUntil: 'load'});
    });

    it('Activity Lifecycle Smoke on PWA MO', async () => {
        await page.emulate(iPhonex);
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=32659|1|0'), { waitUntil: 'load' });
        await page.goto(getEndPoint(), { waitUntil: 'domcontentloaded' });
        await page.waitForSelector(storeFront.thingsToDo);
        await page.click(storeFront.thingsToDo);
        await page.waitForSelector(storeFront.destinationSearchBox);
        await page.type(storeFront.destinationSearchBox, ' Singapore', { delay: 250 });
        await page.keyboard.press('Enter', { delay: 1000 });
        await page.keyboard.press('Enter', { delay: 1000 });
        await page.waitForSelector(srp.secondActivityTile);
        await page.click(srp.secondActivityTile);
        await page.waitForSelector(infosite.checkAvailibilitySecondDate);
        await page.click(infosite.checkAvailibilitySecondDate);
        await page.waitFor(1000); // This is required as it takes some time to return activities of new date
        await page.waitForSelector(infosite.bookButton);
        await page.click(infosite.bookButton);
        await page.waitForSelector(cko.secureBookingText);
        await verifyLabel(cko.secureBookingText, expected().ckoSecureBookingText);
        console.log('Test PASS: Activity Lifecycle Smoke on PWA MO in '+getEndPoint());
    });

    it('Activity Lifecycle Smoke on PWA M1', async () => {
        await page.emulate(iPhonex);
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=32659|1|1'), { waitUntil: 'load' });
        await page.goto(getEndPoint(), { waitUntil: 'domcontentloaded' });
        await page.waitForSelector(storeFront.thingsToDo);
        await page.click(storeFront.thingsToDo);
        await page.waitForSelector(storeFront.destinationSearchBox);
        await page.type(storeFront.destinationSearchBox, ' Singapore', { delay: 250 });
        await page.keyboard.press('Enter', { delay: 1000 });
        await page.keyboard.press('Enter', { delay: 1000 });
        await page.waitForSelector(destinationPage.firstActivityTile);
        await page.click(destinationPage.firstActivityTile);
        await page.waitForSelector(infosite.checkAvailibilitySecondDate);
        await page.click(infosite.checkAvailibilitySecondDate);
        await page.waitFor(1000); // This is required as it takes some time to return activities of new date
        await page.waitForSelector(infosite.bookButton);
        await page.click(infosite.bookButton);
        await page.waitForSelector(cko.secureBookingText);
        await verifyLabel(cko.secureBookingText, expected().ckoSecureBookingText);
        console.log('Test PASS: Activity Lifecycle Smoke on PWA M1 in '+getEndPoint());
    });

    it('Activity Lifecycle Smoke on iPad', async () => {
        await page.emulate(iPad);
        await page.goto(getEndPoint(), { waitUntil: 'domcontentloaded' });
        await page.waitForSelector(storeFront.thingsToDo);
        await page.click(storeFront.thingsToDo);
        await page.waitForSelector(storeFront.destinationSearchBox);
        await page.type(storeFront.destinationSearchBox, ' Singapore', { delay: 250 });
        await page.keyboard.press('Enter', { delay: 1000 });
        await page.keyboard.press('Enter', { delay: 1000 });
        await page.waitForSelector(srp.iPadFirstActityTile);
        await page.click(srp.iPadFirstActityTile);
        await page.waitForSelector(infosite.ipadCheckAvailability);
        await page.click(infosite.ipadCheckAvailability);
        await page.waitForSelector(infosite.ipadBookButton);
        await page.waitFor(4000); //This is required as it tames sometime to enable book button
        await page.click(infosite.ipadBookButton);
        await verifyLabel(cko.secureBookingText, expected().ckoSecureBookingText);
        console.log('Test PASS: Activity Lifecycle Smoke on iPad in '+getEndPoint());
    });
});
