'use strict';
import { destinationPage, srp, infosite, storeFront } from '../elementFactory/elementFactoryPwa';
import { expected, loc } from '../expectationFactory/expectationFactoryPwa';
import { addDays, getEndPoint, iPhonex, pad, verifyLabel } from '../helpers/helper';
import { abacus, account, activityUrl } from '../urlFactory/urlFactoryPwa';


const sortNumber = (a: any, b: any) => parseInt(a, 10) - parseInt(b, 10);
const desSortNumber = (a: any, b: any) => parseInt(b, 10) - parseInt(a, 10);

describe('LX PWA SRP page Test in M0 view', () => {

    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:32262|0|0:32659|0|0:35083|1|1'), { waitUntil: 'load' };
        await page.emulate(iPhonex);
    });

    it('Search with specific destination and date from storeFront', async () => {
        await page.goto(getEndPoint(), {waitUntil: 'domcontentloaded'});
        await page.waitForSelector(storeFront.thingsToDo);
        await page.click(storeFront.thingsToDo);
        await page.waitForSelector(storeFront.destinationSearchBox);
        await page.type(storeFront.destinationSearchBox, ' Singapore, Singapore', {delay: 250});
        console.log('Destination selected by user: Singapore');
        await page.waitForSelector(storeFront.calendarFrom);
        await page.click(storeFront.calendarFrom)
        await page.waitForSelector(storeFront.nextMonthButtonFrom);
        await page.click(storeFront.nextMonthButtonFrom)
        await page.waitForSelector(storeFront.previousMonthButtonFrom);
        await page.waitForSelector(storeFront.pickAnyStartDate);
        const startDateSelected = await page.$eval(storeFront.pickAnyStartDate, (heading) => heading.textContent);
        const startDateMonth = startDateSelected.substring(0, 3);
        const startDateDate= startDateSelected.substring(startDateSelected.length - 2);
        const startdateYear = await page.$eval(storeFront.pickAnyStartDate, (heading) => heading.getAttribute("data-year"));
        const startdateMonth0 = await page.$eval(storeFront.pickAnyStartDate, (heading) => heading.getAttribute("data-month"));
        const startdateDate = await page.$eval(storeFront.pickAnyStartDate, (heading) => heading.getAttribute("data-day"));
        const startdateMonth = parseInt(startdateMonth0)+1;
        await page.click(storeFront.pickAnyStartDate);
        await page.waitForSelector(storeFront.calendarTo);
        await page.click(storeFront.calendarTo);
        await page.waitForSelector(storeFront.pickAnyEndDate);
        const endDateSelected = await page.$eval(storeFront.pickAnyEndDate, (heading) => heading.textContent);
        console.log('Dates selected by user. Start date:' + startDateSelected + '  End date:' + endDateSelected);
        const endDateMonth = endDateSelected.substring(0, 3);
        const endDateDate= endDateSelected.substring(endDateSelected.length - 2);
        const enddateYear = await page.$eval(storeFront.pickAnyEndDate, (heading) => heading.getAttribute("data-year"));
        const enddateMonth0 = await page.$eval(storeFront.pickAnyEndDate, (heading) => heading.getAttribute("data-month"));
        const enddateDate = await page.$eval(storeFront.pickAnyEndDate, (heading) => heading.getAttribute("data-day"));
        const enddateMonth = parseInt(enddateMonth0)+1;
        await page.click(storeFront.pickAnyEndDate);

        await page.waitFor(1000); // This is required as the search button is not clickable because the calendar is still open
        await page.waitForSelector(storeFront.searchButton);
        await page.click(storeFront.searchButton);
        await page.waitForSelector(srp.activityTile);
        const activityCount = (await page.$$(srp.activityTile)).length;
        await expect(activityCount).toBeGreaterThanOrEqual(1);

        //Code to verify specific Destination
        await page.waitForSelector(srp.destination);
        const destinationShownInSrp = await page.$eval(srp.destination, (heading) => heading.textContent);
        await expect(destinationShownInSrp).toContain(expected().destinationTextSingapore);
        const checkUrl = await page.evaluate(() => location.href);
        await expect(checkUrl).toContain('location=Singap');


        //Code to verify specific date
        if(process.env.NODE_ENV?.includes("production")|| process.env.NODE_ENV?.includes("dev") ||process.env.NODE_ENV?.includes("test"))
        {
        await page.waitForSelector(srp.date);
        const dateShownInSrp = await page.$eval(srp.date, (heading2) => heading2.textContent);
        console.log('Activities listed in SRP for the date:',dateShownInSrp);
        await expect(dateShownInSrp).toContain(startDateMonth + ' ' + startDateDate + ' - ' + endDateMonth + ' ' + endDateDate);
        await expect(checkUrl).toContain('startDate=' + pad(startdateMonth,2) + '/' + startdateDate + '/' + startdateYear);
        await expect(checkUrl).toContain('endDate=' + pad(enddateMonth,2) + '/' + enddateDate + '/' + enddateYear);
        console.log('Test PASS: Search with specific destination and date from storeFront in '+getEndPoint());
    }
    else{
        await page.waitForSelector(srp.date);
        const dateShownInSrp = await page.$eval(srp.date, (heading2) => heading2.textContent);
        console.log('Activities listed in SRP for the date:',dateShownInSrp);
        await expect(dateShownInSrp).toContain(startDateDate + '. ' + startDateMonth + ' - ' + endDateDate + '. ' + endDateMonth);
        await expect(checkUrl).toContain('startDate=' + startdateDate+'.'+pad(startdateMonth,2) + '.' + startdateYear);
        await expect(checkUrl).toContain('endDate=' + enddateDate+'.'+pad(enddateMonth,2) + '.' + enddateYear);
        console.log('Test PASS: Search with specific destination and date from storeFront in '+getEndPoint());

    }
    });

    it('SRP Guest user banner and banner position test', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.guestDiscountBanner);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText1);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText2);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText3);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText4);
        const guestUserBanner = await page.$eval(srp.guestDiscountBanner, (heading) => heading.textContent);
        console.log('Guest user banner in MO mode: ',guestUserBanner);
        console.log('Test PASS: SRP Guest user banner and banner position test in '+getEndPoint());
    });

    it('SRP price sort -low to high', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.reload({waitUntil: 'load'}); //temporary fix for the bug- login popup shows by default in app.
        await page.waitForSelector(srp.sortAndFilterButton);
        await page.click(srp.sortAndFilterButton);
        await page.waitForResponse((response) => response.ok());
        await page.waitFor(1000); // This is required as the below selector is visible but click not working on quick execution
        await page.waitForSelector(srp.lowToHighFilter);
        await page.$eval(srp.lowToHighFilter, (elem) => (elem as HTMLElement).click());
        await page.waitForResponse((response) => response.ok());
        await page.waitFor(1000); // This is required as the below selector is visible but click not working on quick execution
        await page.waitForSelector(srp.sortAndFilterPopupDoneButton);
        await page.click(srp.sortAndFilterPopupDoneButton);
        await page.waitForResponse((response) => response.ok());
        await page.reload({ waitUntil: 'load' });
        await page.waitFor(2000); // This is required because the SRP locator is visible when sort by filter popup is open
        await page.waitForSelector(srp.firstActivityTile);
        await page.waitForSelector(srp.showMore, { visible: true });
        await page.waitForSelector(srp.activityTilePrice);
        expect(await page.evaluate(() => document.querySelectorAll('[data-testid="activity-tile"]').length)).toEqual(50);
        const list = await page.evaluate(() => Array.from(document.querySelectorAll('.uitk-lockup-price[aria-hidden="true"]'),
            (element) => element.textContent));
        const prices = list.filter((a) => a !== null).map((item) => {
            if (process.env.NODE_ENV?.includes("test")){
                if (item !== null) {
                return parseInt(item.split('$')[1].split(',').join(''));
                }
                else {
                return NaN;
                }
            }
            if (process.env.NODE_ENV?.includes("DE")){
                    if (item !== null) {
                    return parseInt(item.split(' ')[0].split(',').join(''));
                    }
                    else {
                    return NaN;
                    }
                }
            })

        console.log(process.env.NODE_ENV+': Prices listed in SRP page after Sorting Low to High:', prices);
        const pricesCopy = JSON.parse(JSON.stringify(prices));
        await prices.sort(sortNumber);
        console.log(process.env.NODE_ENV+': prices after sorting Low to High in an array', prices);
        await expect(prices).toEqual(pricesCopy);
        console.log('Test PASS: SRP price sort -low to high in '+getEndPoint());
    });

    it('SRP price sort - high to low', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.sortAndFilterButton);
        await page.click(srp.sortAndFilterButton);
        await page.waitForResponse((response) => response.ok());
        await page.waitFor(1000); // This is required as the below selector is visible but click not working on quick execution
        await page.waitForSelector(srp.highToLowFileter);
        await page.$eval(srp.highToLowFileter, (elem) => (elem as HTMLElement).click());
        await page.waitForResponse((response) => response.ok());
        await page.waitForSelector(srp.sortAndFilterPopupDoneButton);
        await page.click(srp.sortAndFilterPopupDoneButton);
        await page.waitForResponse((response) => response.ok());
        await page.reload({ waitUntil: 'load' });
        await page.waitFor(2000); // This is required because the SRP locator is visible when sort by filter popup is open
        await page.waitForSelector(srp.activityTile);
        await page.waitForSelector(srp.activityTilePrice);
        await page.waitForSelector(srp.showMore);
        await page.waitForSelector(srp.activityTilePrice);
        const list = await page.evaluate(() => Array.from(document.querySelectorAll('.uitk-lockup-price[aria-hidden="true"]'),
            (element) => element.textContent));
        const prices = list.map((item) => {
            if (process.env.NODE_ENV?.includes("test")){
                if (item !== null) {
                return parseInt(item.split('$')[1].split(',').join(''));
                }
                else {
                return NaN;
                }
            }
            if (process.env.NODE_ENV?.includes("DE")){
                if (item !== null) {
                return parseInt(item.split(' ')[0].split(',').join(''));
                }
                else {
                return NaN;
                }
            }
        })
        console.log(process.env.NODE_ENV+': Prices listed in SRP page after Sorting High to Low:', prices);
        const pricesCopy = JSON.parse(JSON.stringify(prices));
        prices.sort(desSortNumber);
        console.log(process.env.NODE_ENV+': prices after sorting High to Low in an array', prices);
        await expect(pricesCopy).toEqual(prices);
        console.log('Test PASS: SRP price sort - high to low in '+getEndPoint());
    });

    it('SRP Category and sub category filter search', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.reload({waitUntil: 'load'}); //temporary fix for the bug- login popup shows by default in app.
        await page.waitForSelector(srp.firstActivityTile);
        await page.click(srp.sortAndFilterButton);
        //await page.waitForResponse((response) => response.ok());
        await page.waitForSelector(srp.tourAndDayTripsCategory);
        await page.waitFor(1000); // This is required as the below locator is visible but click is not enabled
        await page.click(srp.tourAndDayTripsCategory);
        //await page.waitForResponse((response) => response.ok());
        await page.waitFor(1000); // This is required as the below locator is visible but click is not enabled
        //await verifyFilterIsSelected(srp.tourAndDayTripsCategory);
        await page.click(srp.sortAndFilterPopupDoneButton);
        await page.waitForSelector(srp.pillText);
        await verifyLabel(srp.pillText, expected().ToursAndDayTripsCategoryPillText);
        const categoryFilterValue = await page.$eval(srp.pillText, (heading) => heading.textContent);
        console.log('Category filter in M0 mode: ',categoryFilterValue);
        await page.click(srp.pillText);
        await page.waitForSelector(srp.firstActivityTile);
        await page.reload({waitUntil: 'load'}); //temporary fix for the bug- console error
        await page.waitForSelector(srp.sortAndFilterButton);
        await page.waitFor(2000); // This is required as category filter takes some time to become uncheck status
        await page.click(srp.sortAndFilterButton);
        //await page.waitForResponse((response) => response.ok());
        await page.waitForSelector(srp.tourAndDayTripsCategory);
        await page.waitFor(1000); // This is required as the below locator is visible but click is not enabled
        await page.click(srp.tourAndDayTripsCategory);
        //await page.waitForResponse((response) => response.ok());
        await page.waitForSelector(srp.cityTours);
        await page.waitFor(1000); // This is required as the below locator is visible but click is not enabled
        await page.click(srp.cityTours);
        //await page.waitForResponse((response) => response.ok());
        await page.waitFor(1000); // This is required as the below locator is visible but click is not enabled
        //await verifyFilterIsSelected(srp.cityTours);
        await page.waitForSelector(srp.sortAndFilterPopupDoneButton);
        await page.click(srp.sortAndFilterPopupDoneButton);
        //await page.waitForResponse((response) => response.ok());
        await page.reload({ waitUntil: 'load' });
        await page.waitForSelector(srp.activityTile);
        await page.waitForSelector(srp.pillText);
        await verifyLabel(srp.pillText, expected().cityToursFilterPillText);
        const subCategoryFilterValue = await page.$eval(srp.pillText, (heading) => heading.textContent);
        console.log('Sub Category filter in M0 mode: ',subCategoryFilterValue);
        console.log('Test PASS: SRP Category and sub category filter search in '+getEndPoint());
    });

    it('SRP Sort filter clear button', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.reload({ waitUntil: 'load' });
        await page.waitForSelector(srp.activityTile);
        await page.waitForFunction(() => document.querySelectorAll('[data-testid="activity-tile"]').length > 49, {
            polling: 'mutation',
        }, { waitUntil: 'load' });
        await page.waitForSelector(srp.showMore);
        const list1 = await page.evaluate(() => Array.from(document.querySelectorAll('.uitk-lockup-price'),
            (element) => element.textContent));
        const pricesBefore = list1.map((item) => {
            if (process.env.NODE_ENV?.includes("test")){
                if (item !== null) {
                return parseInt(item.split('$')[1].split(',').join(''));
                } else {
                return NaN;
                }
            }
            if (process.env.NODE_ENV?.includes("DE")){
                if (item !== null) {
                return parseInt(item.split(' ')[0].split(',').join(''));
                } else {
                return NaN;
                }
            }
        })
        console.log(process.env.NODE_ENV+': Prices listed in SRP page before clear button:', pricesBefore);

        await page.click(srp.sortAndFilterButton);
        await page.waitForResponse((response) => response.ok());
        await page.waitFor(1000); // This is required as the below locator is visible but click is not enabled
        await page.waitForSelector(srp.slimSearch);
        await page.type(srp.slimSearch, 'tour', {delay: 250});
        await page.click(srp.highToLowFileter);
        const sortCheck = await page.evaluate((checkbox) => checkbox.sortCheck, await page.$(srp.highToLowFileter));
        await page.waitForSelector(srp.sortAndFilterPopupWaterActivityCategory);
        await page.click(srp.sortAndFilterPopupWaterActivityCategory);
        const categorySelecter = await page.evaluate((checkbox) => checkbox.categorySelecter, await page.$(srp.sortAndFilterPopupWaterActivityCategory));
        await page.click(srp.sortAndFilterPopupClearButton)
        await page.waitFor(2000); // This is required as the below locator is visible but not enabled
        await page.waitForSelector(srp.highToLowFileter);
        const sortCheckbox = await page.$(srp.highToLowFileter);
        sortCheckbox !== null ?
            await expect(await (await sortCheckbox.getProperty('checked')).jsonValue()).toBeFalsy() :
            fail(new Error('sortCheckbox is null'));
        const categoryCheckbox = await page.$(srp.sortAndFilterPopupWaterActivityCategory);
        categoryCheckbox !== null ?
            await expect(await (await categoryCheckbox.getProperty('checked')).jsonValue()).toBeFalsy() :
            fail(new Error('categoryCheckbox is null'));
        await page.waitFor(1000); // This is required as the below locator is visible but not enabled
        await page.click(srp.sortAndFilterPopupDoneButton);
        await page.waitForResponse((response) => response.ok());
        await page.waitFor(2000); // This is required because the SRP locator is visible when sort by filter popup is open
        await page.waitForSelector(srp.activityTile);
        await page.waitForFunction(() => document.querySelectorAll('.uitk-card-link').length > 49, {
            polling: 'mutation',
        }, { waitUntil: 'load' });
        await page.waitForSelector(srp.activityTilePrice);
        const list2 = await page.evaluate(() => Array.from(document.querySelectorAll('.uitk-lockup-price'),
            (element) => element.textContent));
        const pricesAfter = list2.map((item) => {
                if (process.env.NODE_ENV?.includes("test")){
                    if (item !== null) {
                    return parseInt(item.split('$')[1].split(',').join(''));
                    } else {
                    return NaN;
                    }
                }
                if (process.env.NODE_ENV?.includes("DE")){
                    if (item !== null) {
                    return parseInt(item.split(' ')[0].split(',').join(''));
                    } else {
                    return NaN;
                    }
                }
        });
        console.log(process.env.NODE_ENV+': Prices listed in SRP page after clear button:', pricesAfter);
        await expect(pricesBefore).toEqual(pricesAfter);
        console.log('Test PASS: SRP Sort filter clear button in'+getEndPoint());
    });

    it('SRP Slim or Keyword Search', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.reload({ waitUntil: 'load' });
        await page.waitForSelector(srp.sortAndFilterButton);
        await page.click(srp.sortAndFilterButton);
        await page.waitForResponse((response) => response.ok());
        await page.waitForSelector(srp.slimSearch);
        await page.type(srp.slimSearch,'Hotel', {delay: 500});
        await page.keyboard.press('Enter', { delay: 1000 });
        console.log('Keyword entered by user:','Hotel');
        await page.waitFor(1000); // This is required as the below locator is visible but not enabled
        const checkUrl = await page.evaluate(() => location.href);
        await expect(checkUrl).toContain('SearchKeyword');
        await expect(checkUrl).toContain('=');
        await expect(checkUrl).toContain('Hotel');
        await verifyLabel(srp.pillText, 'Hotel');
        const activityName = await page.$eval(srp.allContents, (el) => el.innerText);
        await expect(activityName).toContain('Hotel');
        const keyWordSearchValue = await page.$eval(srp.pillText, (heading) => heading.textContent);
        console.log('Keyword shown in pill after search with a keyword:',keyWordSearchValue);
        console.log('Test PASS: SRP Slim or Keyword Search in '+getEndPoint());
    });

    it('SRP pagination test and showmore button visibilty', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.sortAndFilterButton);
        await page.waitForSelector(srp.activityAndCategoryPillCountSrp);
        var pageNumber = 1;
        var activityCount = await page.evaluate(() => {return document.querySelectorAll('a.uitk-card-link').length;});

        while (await page.$(srp.showMore) !== null  && activityCount < 150){
            pageNumber=pageNumber+1;
            await page.click(srp.showMore);
            await page.waitForFunction( `document.querySelectorAll('a.uitk-card-link').length > ${activityCount}`);
            await page.waitFor(3000);//This is required as it found that it takes some time load the entire actvities
            activityCount = await page.evaluate(() => {return document.querySelectorAll('a.uitk-card-link').length});
        }
        console.log('Number of pages shown:',pageNumber);
        console.log('Total Activity count:',activityCount);
        await expect(activityCount).not.toBeLessThan( pageNumber * 50 - 50);
        await expect(activityCount).not.toBeGreaterThan( pageNumber * 50 );
        console.log('Test PASS: SRP pagination test and showmore button visibilty , Environment:'+getEndPoint());
    });

    it('SRP default search result is Recommended and swp is ON', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.sortAndFilterButton);
        await page.click(srp.sortAndFilterButton);
        await page.waitForSelector(srp.sortAndFilterPopupRecommendedButton);
        const checkbox = await page.$(srp.sortAndFilterPopupRecommendedButton);
        await expect(await (await checkbox.getProperty('checked')).jsonValue()).toBeTruthy();
        const checkUrl = await page.evaluate(() => location.href);
        await expect(checkUrl).toContain('sort=RECOMMENDED');
        await expect(checkUrl).toContain('swp=on');
        console.log('Default search result is \'recommended\' and SWP is \'ON\' ');
        console.log('Test PASS: SRP default search result is Recommended and swp is ON in '+getEndPoint());
    });

    it('SRP default search location and date', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.destination);
        const activityCount2 = (await page.$$(srp.activityTile)).length;
        await expect(activityCount2).toBeGreaterThanOrEqual(1);

        //Code to check default Search Destination is correct
        const destinationBefore = await page.$eval(srp.destination, (heading) => heading.textContent);
        await expect(destinationBefore).toContain(expected().destinationTextRome);
        const checkUrl = await page.evaluate(() => location.href);
        await expect(checkUrl).toContain('location=Rom');
        console.log ('Destination shown in default search:',destinationBefore);

        //Code to check default Search start Date is current date
        const defaultDates = await page.$eval(srp.date, (heading2) => heading2.textContent);
        const date = new Date();
        const todayYear=date.getFullYear();
        var todayMonthInNumber=date.getMonth()+1;
        if(todayMonthInNumber.toString().length === 1) {
            var todayMonthInNumberWithZero = '0'+todayMonthInNumber;
        }
        //const todayMonthInNumber = parseInt(todayMonthInNumberWithLeftZero,10);
        const todayMonthInLetters = date.toDateString().substring(4, 7);
        const todaydDateWithLeftZero = date.toDateString().substring(8, 10);
        const todaydDate = parseInt(todaydDateWithLeftZero,10);;
        await expect(defaultDates).toContain(todayMonthInLetters);
        await expect(defaultDates).toContain(todaydDate);
        if (process.env.NODE_ENV?.includes("test")){
        await expect(checkUrl).toContain('startDate=' + todayMonthInNumber + '%2F' + todaydDate + '%2F' + todayYear);
        }
        else {
        await expect(checkUrl).toContain('startDate=' + todaydDate + '.' + todayMonthInNumberWithZero + '.' + todayYear);
        }

        //Code to check default Search end Date is current date + 14
        const defaultEndDate = addDays(14);
        const defaultEndDateYear=defaultEndDate.substring(0,4);
        const defaultEndDateMonthInNumberWithLeftZero=defaultEndDate.substring(5,7);
        const defaultEndDateMonthInNumber = parseInt(defaultEndDateMonthInNumberWithLeftZero,10);
        const defaultEndDateDateWithLeftZero=defaultEndDate.substring(8,10);
        const defaultEndDateDate = parseInt(defaultEndDateDateWithLeftZero,10);
        await expect(defaultDates).toContain(defaultEndDateDate);
        if (process.env.NODE_ENV?.includes("test")){
        await expect(checkUrl).toContain('endDate=' + defaultEndDateMonthInNumber + '%2F' + defaultEndDateDate + '%2F' + defaultEndDateYear);
        }
        else {
        await expect(checkUrl).toContain('endDate=' + defaultEndDateDate + '.' + defaultEndDateMonthInNumberWithLeftZero + '.' + todayYear);
        }
        console.log('Date shown for default search:',defaultDates);
        console.log('Test PASS: SRP default search and date in '+getEndPoint());
    });

    it('SRP Change Search with change in Destination and date', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.destination);

        //Code to check modify destination
        await page.click(srp.destination);
        await page.waitForSelector(srp.destinationEditField);
        await page.click(srp.destinationEditField);
        for (let i = 0; i < 50; i++) {
            await page.keyboard.press('Backspace');
        }
        await page.keyboard.type('Singa', { delay: 500 });
        await page.waitFor(3000); // This is required as it takes some time to display dropdown of destinations
        await page.keyboard.press('Tab', { delay: 1000 });
        await page.keyboard.press('Tab', { delay: 1000 });
        await page.keyboard.press('Enter', { delay: 1000 });
        console.log ('New Destination entered by user: Singapore');
        await page.waitForNavigation({waitUntil: 'load'});
        await page.waitForSelector(srp.destination);
        const destinationAfter = await page.$eval(srp.destination, (heading) => heading.textContent);
        await expect(destinationAfter).toContain(expected().destinationTextSingapore);
        const checkUrl2 = await page.evaluate(() => location.href);
        await expect(checkUrl2).toContain('location=Singap');
        console.log ('Destination shown after change search: ',destinationAfter);

        //Code to check modify date
        await page.click(srp.destination);
        await page.waitForSelector(srp.startDateButton);
        await page.click(srp.startDateButton);
        await page.waitForSelector(srp.pickAnyStartDate);
        await page.click(srp.pickAnyStartDate);
        await page.click(srp.pickAnyEndDate);
        var startDate;
        var endDate;
        var  startDateDate;
        var  endDateDate;

        if (process.env.NODE_ENV?.includes("test")){
        const startDateWithDay = await page.$eval(srp.startDateSelected, (heading) => heading.textContent);
        console.log('startDateWithDay',startDateWithDay);
        startDate = startDateWithDay.substring(5, 12);
        const startDateDateWithLeftZero=startDateWithDay.substring(8, 12);
        startDateDate = parseInt(startDateDateWithLeftZero,10);
        const endDateWithDay = await page.$eval(srp.endDateSelected, (heading) => heading.textContent);
        endDate = endDateWithDay.substring(5, 12);
        const endDateDateWithLeftZero=endDateWithDay.substring(8, 12);
        endDateDate = parseInt(endDateDateWithLeftZero,10);
        }
        else if (process.env.NODE_ENV?.includes("de"){
        const startDateWithDay = await page.$eval(srp.startDateSelected, (heading) => heading.textContent);
        startDate = startDateWithDay.substring(5, 12);
        console.log('endDate',endDate);
        startDateDate = parseInt(startDate.split('.')[0]);
        if (startDateDate.toString().length === 1) {
            startDateDate = '0'+startDateDate;
        }
        const endDateWithDay = await page.$eval(srp.endDateSelected, (heading) => heading.textContent);
        endDate = endDateWithDay.substring(5, 12);
        console.log('endDate',endDate);
        endDateDate = parseInt(endDate.split('.')[0]);
        if (endDateDate.toString().length === 1) {
            endDateDate = '0'+endDateDate;
        }
        }
        console.log('New dates selected by user. Start date:',startDate,', End date:',endDate);
        await page.click(srp.dateModifySearchButton);
        await page.waitForNavigation({waitUntil: 'load'});
        const activityCount2 = (await page.$$(srp.activityTile)).length;
        await expect(activityCount2).toBeGreaterThanOrEqual(1);
        await page.waitForSelector(srp.date);
        const dateShownInSrp = await page.$eval(srp.date, (heading2) => heading2.textContent);
        console.log('Date shown after change search:',dateShownInSrp);

        if (process.env.NODE_ENV?.includes("test")){
        await expect(dateShownInSrp).toContain(startDate + ' - ' + endDate);
        const checkUrl3 = await page.evaluate(() => location.href);
        await expect(checkUrl3).toContain('%2F' + startDateDate + '%2F' );
        await expect(checkUrl3).toContain('%2F' + endDateDate + '%2F' );
        }
        else if (process.env.NODE_ENV?.includes("de"){
        await expect(dateShownInSrp).toContain(startDate + ' - ' + endDate);
        const checkUrl4 = await page.evaluate(() => location.href);
        await expect(checkUrl4).toContain('startDate='+startDateDate);
        await expect(checkUrl4).toContain('endDate='+endDateDate);
        }
        console.log('Test PASS: SRP Change Search with change in Destination and date in '+getEndPoint());
    });

    it('SRP pinned activity display', async () => {
        await page.goto(getEndPoint() + activityUrl.pinnedActivity, { waitUntil: 'load' });
        await page.waitForFunction(() => document.querySelectorAll('.uitk-card-link').length > 40, {
            polling: 'mutation',
        });
        await page.waitForSelector(srp.pinnedActivityText);;
        const activityText = await page.$eval(srp.pinnedActivityText, (heading) => heading.textContent);
        await expect(activityText).toContain(expected().pinnedActivityText);
        console.log('Pinned activity text:',activityText);
        console.log('Test PASS: SRP pinned activity display in '+getEndPoint());
    });

    it('SRP page test for SWP functionality', async () => {
       //This functionality is available only to US and UK POS
       if (process.env.NODE_ENV?.includes("test")){
        await page.goto(getEndPoint() + account.swpLogin, {waitUntil: 'load',});
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, {waitUntil: 'load'});

        //code to check url contains the defeault value of swp is ON
        const checkUrl = await page.evaluate(() => location.href);
        await expect(checkUrl).toContain('swp=on');

        //code to check SWP banner comes correctly in SRP page
        await page.waitForSelector(srp.swpBanner);
        const swpText = await page.$eval(srp.swpBanner, (el) => el.innerText);
        console.log('SWP Points text is: ', swpText);
        await expect(swpText).toContain(expected().swpBanner);
        await expect(swpText).toContain(expected().currencySymbol);
        await expect(swpText).not.toContain(expected().currencySymbol + 0);
        await expect(swpText).not.toContain(expected().currencySymbol + ' ');

        //code to check Points are applying in SRP and IS when swp value is ON
        await page.waitForSelector(srp.activityTilePrice);
        const actualPrice = await page.$eval(srp.strikedOutPrice, (heading) => heading.textContent);
        console.log('Actual price in SRP:',actualPrice);
        const actualPriceInSrpWithoutComma = parseInt(actualPrice.split('$')[1].split(',').join(''));
        const offerPriceInSrp = await page.$eval(srp.activityTilePrice, (heading) => heading.textContent);
        console.log('Offer price in SRP:',offerPriceInSrp);
        const offerPriceInSrpWithoutComma = parseInt(offerPriceInSrp.split('$')[1].split(',').join(''));

        await page.click(srp.activityTilePrice);
        await page.waitForSelector(infosite.actualPrice);
        await page.waitForSelector(infosite.pointsApplied);
        await verifyLabel(infosite.pointsApplied, expected().pointsAppliedIsPageText);
        var actualPriceInIS;
        var offerPriceInIS;
        await page.waitForSelector(infosite.offerPrice);
        if (await page.$('.offer-strike-out-price.all-r-padding-two > del') === null){
        actualPriceInIS = await page.$eval(infosite.actualPrice, (heading) => heading.textContent);
        console.log('Actual Price in IS:',actualPriceInIS);
        offerPriceInIS = await page.$eval(infosite.offerPrice, (heading) => heading.textContent);
        console.log('Offer price in IS:',offerPriceInIS);
        }

        if (await page.$('.offer-strike-out-price.all-r-padding-two > del') !== null){
        actualPriceInIS = await page.$eval(infosite.nonDiscountedOfferPrice, (heading) => heading.textContent);
        console.log('Actual Price in IS:',actualPriceInIS);
        offerPriceInIS = await page.$eval(infosite.offerPrice, (heading) => heading.textContent);
        console.log('Offer price in IS:',offerPriceInIS);
        }

        const actualPriceInIsWithoutCommaAndDecimalPoint = parseInt(actualPriceInIS.split('$')[1].split('.')[0].split(',').join(''));
        const decimalPointValueForActualPrice = parseInt(actualPriceInIS.split('.')[1]);
        if (decimalPointValueForActualPrice > 0){
        await expect(actualPriceInSrpWithoutComma).toEqual(actualPriceInIsWithoutCommaAndDecimalPoint + 1) ;
        }
        else {
        await expect(actualPriceInSrpWithoutComma).toEqual(actualPriceInIsWithoutCommaAndDecimalPoint);
        }

        const offerPriceInIsWithoutCommaAndDecimalPoint = parseInt(offerPriceInIS.split('$')[1].split('.')[0].split(',').join(''));
        const decimalPointValueForOfferPrice = parseInt(offerPriceInIS.split('.')[1]);
        if (decimalPointValueForOfferPrice > 0){
        await expect(offerPriceInSrpWithoutComma).toEqual(offerPriceInIsWithoutCommaAndDecimalPoint+1) ;
        }
        else {
        await expect(offerPriceInSrpWithoutComma).toEqual(offerPriceInIsWithoutCommaAndDecimalPoint);
        }

        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        console.log('Test PASS: SRP page test for SWP functionality in ' + getEndPoint());
        }
        else{
        console.log('SRP page test for SWP banner functionality is not applicable to the pos ' + getEndPoint())
        }
    });

});

describe('LX PWA SRP page Test in M1 view', () => {
    beforeAll(async () => {

        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:31970|1|1|:32194|1|1|:32200|1|1|:32659|1|1:35083|1|1');
        await page.emulate(iPhonex);
    });

    it('SRP M1 test for Guest user banner and position in M1 mode', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'load' });

        //Code to check Guest user banner in Destination view
        await page.waitForSelector(destinationPage.guestDiscountBanner);
        await verifyLabel(destinationPage.guestDiscountBanner, expected().guestDiscountBannerText1);
        await verifyLabel(destinationPage.guestDiscountBanner, expected().guestDiscountBannerText2);
        await verifyLabel(destinationPage.guestDiscountBanner, expected().guestDiscountBannerText3);
        await verifyLabel(destinationPage.guestDiscountBanner, expected().guestDiscountBannerText4);
        const guestUserBannertDestinationViewM1 = await page.$eval(destinationPage.guestDiscountBanner, (heading) => heading.textContent);
        console.log('Guest user banner in Destination view M1 mode: ',guestUserBannertDestinationViewM1);

        //Code to check Guest user banner in list view
        await page.waitForSelector(destinationPage.seeAllThingsToDo);
        await page.click(destinationPage.seeAllThingsToDo);
        await page.waitForSelector(srp.pillText);
        await page.waitForSelector(srp.guestDiscountBanner);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText1);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText2);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText3);
        await verifyLabel(srp.guestDiscountBanner, expected().guestDiscountBannerText4);
        const guestUserBannerListViewM1 = await page.$eval(srp.guestDiscountBanner, (heading) => heading.textContent);
        console.log('Guest user banner in List view M1 mode: ',guestUserBannerListViewM1);
        console.log('Test PASS: SRP M1 test for Guest user banner and position in M1 mode in '+getEndPoint());

    });

    it('SRP M1 test for slim or keyword search', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.waitForSelector(destinationPage.slimSearch);
        await page.type(destinationPage.slimSearch,'Hotel', {delay: 1000});
        await page.keyboard.press('Enter', { delay: 300 });
        console.log('Keyword entered by user for slim search:','Hotel');
        await page.waitFor(1000); // This is required as the below locator is visible but not enabled
        const checkUrl = await page.evaluate(() => location.href);
        await expect(checkUrl).toContain('SearchKeyword');
        await expect(checkUrl).toContain('=');
        await expect(checkUrl).toContain('Hotel');
        await verifyLabel(srp.pillText, 'Hotel');
        const activityName = await page.$eval(srp.allContents, (el) => el.innerText);
        await expect(activityName).toContain('Hotel');
        const keyWordSearchValue = await page.$eval(srp.pillText, (heading) => heading.textContent);
        console.log('Keyword shown in pill after search with keyword:',keyWordSearchValue);
        console.log('Test PASS: SRP M1 test for slim or keyword search in '+ getEndPoint());

    });

    it('SRP M1 test for top 10 activities display', async () => {
        await page.goto(getEndPoint() + activityUrl.romeSrp, { waitUntil: 'domcontentloaded' });
        await page.reload({waitUntil: 'load'}); //temporary fix for the bug- login popup shows by default in app.
        await page.waitForSelector(destinationPage.top10ThingsToDoActivityTiles);
        const top10ThingsToDoHeader = await page.$eval(destinationPage.top10ThingsToDoHeader, (heading) => heading.textContent);
        console.log('Top10 Things to do header:',top10ThingsToDoHeader);
        await verifyLabel(destinationPage.top10ThingsToDoHeader, expected().top10ThingsToDoHeader);
        const top10ActivityTileCount = (await page.$$(destinationPage.top10ThingsToDoActivityTiles)).length;
        await expect(top10ActivityTileCount).toBe(10);
        await page.click(destinationPage.top10ThingsToDoActivity10);
        await page.waitForSelector(infosite.backToSrpPageButton);
        await page.waitFor(2000);//This is required as sticky bar is not abl to click eventhough it is visible
        await page.waitForSelector(infosite.checkAvailabilityStickyBar);
        await page.click(infosite.checkAvailabilityStickyBar);
        await page.click(infosite.backToSrpPageButton);
        await page.waitForSelector(destinationPage.Top10ThingsToDoSeeAll);
        await page.click(destinationPage.Top10ThingsToDoSeeAll);
        await page.waitForSelector(srp.pillText);
        await verifyLabel(srp.pillText, expected().top10ThingsToDoSeeAllPillText);
        await page.click(srp.pillText);
        await page.waitForSelector(destinationPage.top10ThingsToDoActivityTiles);
        const top10ActivityTileCount2 = (await page.$$(destinationPage.top10ThingsToDoActivityTiles)).length;
        await expect(top10ActivityTileCount2).toBe(10);
        console.log('Top10 Things to do Tile count:',top10ActivityTileCount2);
        console.log('Test PASS: SRP M1 test for top 10 activities display in '+ getEndPoint());
    });

    it('SRP M1 test for browse by category display', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.waitForSelector(destinationPage.browseByCategorySubCategoryHeader);
        await page.waitForSelector(destinationPage.browseByCategorySubCategoryTiles);
        const browseByCategoryHeader = await page.$eval(destinationPage.browseByCategorySubCategoryHeader, (heading) => heading.textContent);
        console.log('Browse By Category header:',browseByCategoryHeader);
        await verifyLabel(destinationPage.browseByCategorySubCategoryHeader, expected().browseByCaegoryHeader);
        await page.waitForSelector(destinationPage.browseByCategorySubcategoryTile6);
        const browseByCategoryTileCount = (await page.$$(destinationPage.browseByCategorySubCategoryTiles)).length;
        await expect(browseByCategoryTileCount).toBe(6);
        const category1 = await page.$eval(destinationPage.browseByCategorySubcategoryNameTile1, (heading) => heading.textContent);
        console.log('First category: ',category1);
        await page.click(destinationPage.browseByCategorySubcategoryTile1);
        await page.waitForSelector(srp.pillText);
        const categorypill = await page.$eval(srp.pillText, (heading) => heading.textContent);
        console.log('Category selected by user: ',categorypill);
        await expect(category1).toEqual(categorypill);
        await page.click(destinationPage.CategorySubcategoryPill);
        await page.waitForSelector(destinationPage.browseByCategorySubcategoryTile6);
        await page.click(destinationPage.browseByCategorySubcategoryTile6);
        await page.waitForSelector(srp.sortAndFilterPopupDoneButton);
        console.log('Browse By Category Tile Count:',browseByCategoryTileCount);
        console.log('Test PASS: SRP M1 test for browse by category display in '+getEndPoint());
    });

    it('SRP M1 test for browse by More things to do activity tile display', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.waitForSelector(destinationPage.moreThingsToDoHeader);
        await verifyLabel(destinationPage.moreThingsToDoHeader,expected().moreThingsToDoHeader);
        const moreThingsToDoHeader = await page.$eval(destinationPage.moreThingsToDoHeader, (heading) => heading.textContent);
        console.log('More things to do header:',moreThingsToDoHeader);
        await page.waitForSelector(destinationPage.moreThingsToDoTiles);
        const moreThingsToDoActivityTileCount = (await page.$$(destinationPage.moreThingsToDoTiles)).length;
        await expect(moreThingsToDoActivityTileCount).toBe(10);
        await page.click(destinationPage.moreThingsToDoTiles);
        await page.waitForSelector(infosite.bookButton);
        await page.click(infosite.backToSrpPageButton);
        await page.waitForSelector(destinationPage.seeAllThingsToDo);
        await page.click(destinationPage.seeAllThingsToDo);
        await page.waitForSelector(srp.pillText);
        await verifyLabel(srp.pillText, expected().moreThingsToDoSeeAllThingsToDoPillText);
        await page.click(srp.pillText);
        await page.waitForSelector(destinationPage.seeAllThingsToDo);
        const moreThingsToDoActivityTileCount2 = (await page.$$(destinationPage.moreThingsToDoTiles)).length;
        await expect(moreThingsToDoActivityTileCount2).toBe(10);
        console.log('More things to do Activity Tile Count:',moreThingsToDoActivityTileCount2);
        console.log('Test PASS: SRP M1 test for browse by More things to do activity tile display in '+getEndPoint());
    });

    it('SRP pinned activity along with similar recommendation for SEM User (AB-35084)', async () => {
        const visibilty = {visible:true} ;
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=35084|1|1'), { waitUntil: 'load' };
        await page.goto(getEndPoint() + activityUrl.pinnedActivity, { waitUntil: 'load' });
        await page.waitForFunction(() => document.querySelectorAll('.uitk-card-link').length > 40, {
            polling: 'mutation',
        });
        await page.waitForSelector(srp.pinnedActivity, visibilty)
        await page.waitForSelector(srp.pinnedActivityText, visibilty);
        await page.waitForSelector(srp.pinnedRecommendedActivitySection, visibilty);
        await page.waitForSelector(srp.pinnedRecommendedActivitySectionText, visibilty);
        await page.waitForSelector(srp.pinnedRecommendedActivityList, visibilty);
        expect(await page.evaluate(() => document.querySelectorAll('[data-testid="activity-carousel--section"]>div>div>ul>li').length)).toEqual(3);
        const pinnedRecommendedActivitySectionText = await page.$eval(srp.pinnedRecommendedActivitySectionText, (heading) => heading.textContent);
        await expect(pinnedRecommendedActivitySectionText).toContain(expected().pinnedRecommendedActivityText);
        console.log('SRP pinned activity along with similar recommendation for SEM User (AB-35084) '+ getEndPoint());
    });
});

describe('Verify Disney activity is displayed at first position for M0 view', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=32186|1|1:32659|0|0:35083|1|1', { waitUntil: 'load' });
        await page.emulate(iPhonex);
    });

    it('Verifying Disney activity for M0 view | Los Angeles', async () => {
        if(process.env.NODE_ENV?.includes("production")|| process.env.NODE_ENV?.includes("dev") ||process.env.NODE_ENV?.includes("test"))
        { await page.goto(getEndPoint() + activityUrl.losAngelesSrp, { waitUntil: 'load' });
          await page.waitForSelector(srp.firstActivityTitle);
          await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleLA);
          console.log('Disney displays at first position in M0 view for Los Angeles');
          console.log('Test PASS: Verifying Disney activity for M0 view | Los Angeles in '+ getEndPoint());
        }
        else
        { console.log('Skip Test for DE: Verifying Disney activity for M0 view | Los Angeles in '+ getEndPoint());
        }
    });

    it('Verifying Disney activity for M0 view | Orange County', async () => {
        if(process.env.NODE_ENV?.includes("production")|| process.env.NODE_ENV?.includes("dev") ||process.env.NODE_ENV?.includes("test"))
        { await page.goto(getEndPoint() + activityUrl.orangeCountySrp, { waitUntil: 'load' });
          await page.waitForSelector(srp.firstActivityTitle);
          await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleLA);
          console.log('Disney displays at first position in M0 view for Orange County');
          console.log('Test PASS: Verifying Disney activity for M0 view | Orange County in '+ getEndPoint());
        }
        else
        { console.log('Skip Test for DE: Verifying Disney activity for M0 view | Orange County in '+ getEndPoint());
        }
    });

    it('Verifying Disney activity for M0 view | Orlando', async () => {
        await page.goto(getEndPoint() + activityUrl.orlandoSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.firstActivityTitle);
        await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleOrlando);
        console.log('Disney displays at first position in M0 view for Orlando route');
        console.log('Test PASS: Verifying Disney activity for M0 view | Orlando in '+ getEndPoint());
    });

    it.skip('Verifying Disney activity for M0 view | Paris', async () => {
        await page.goto(getEndPoint() + activityUrl.parisSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.firstActivityTitle);
        await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleParis);
        console.log('Disney displays at first position in M0 view for Paris route');
        console.log('Test PASS: Verifying Disney activity for M0 view | Paris in '+ getEndPoint());
    });
});

describe('Verify Disney activity is displayed at first position for M1 view', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto(getEndPoint() + 'tools/abacus/overrides?abov=32186|1|1:32659|0|1:35083|1|1', { waitUntil: 'load' });
        await page.emulate(iPhonex);
    });

    it('Verifying Disney activity for M1 view | Los Angeles', async () => {
        if(process.env.NODE_ENV?.includes("production")|| process.env.NODE_ENV?.includes("dev") ||process.env.NODE_ENV?.includes("test"))
        { await page.goto(getEndPoint() + activityUrl.losAngelesSrp, { waitUntil: 'load' });
          await (await page.waitForSelector(destinationPage.Top10ThingsToDoSeeAll)).click();
          await page.waitForSelector(srp.firstActivityTitle);
          await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleLA);
          console.log('Disney displays at first position in M1 view for Los Angeles');
          console.log('Test PASS: Verifying Disney activity for M1 view | Los Angeles in '+ getEndPoint());
        }
        else
        { console.log('Skip Test for DE: Verifying Disney activity for M1 view | Los Angeles in '+ getEndPoint());
        }
    });

    it('Verifying Disney activity for M1 view | Orange County', async () => {
        if(process.env.NODE_ENV?.includes("production")|| process.env.NODE_ENV?.includes("dev") ||process.env.NODE_ENV?.includes("test"))
        { await page.goto(getEndPoint() + activityUrl.orangeCountySrp, { waitUntil: 'load' });
          await (await page.waitForSelector(destinationPage.Top10ThingsToDoSeeAll)).click();
          await page.waitForSelector(srp.firstActivityTitle);
          await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleLA);
          console.log('Disney displays at first position in M1 view for Orange County');
          console.log('Test PASS: Verifying Disney activity for M1 view | Orange County in ' + getEndPoint());
        }
        else
        { console.log('Skip Test for DE: Verifying Disney activity for M1 view | Orange County in '+ getEndPoint());
        }
    });

    it('Verifying Disney activity for M1 view | Orlando', async () => {
        await page.goto(getEndPoint() + activityUrl.orlandoSrp, { waitUntil: 'load' });
        await (await page.waitForSelector(destinationPage.Top10ThingsToDoSeeAll)).click();
        await page.waitForSelector(srp.firstActivityTitle);
        await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleOrlando);
        console.log('Disney displays at first position in M1 view for Orlando');
        console.log('Test PASS: Verifying Disney activity for M1 view | Orlando in '+ getEndPoint());
    });

    it.skip('Verifying Disney activity for M1 view | Paris', async () => {
        await page.goto(getEndPoint() + activityUrl.parisSrp, { waitUntil: 'load' });
        await (await page.waitForSelector(destinationPage.Top10ThingsToDoSeeAll)).click();
        await page.waitForSelector(srp.firstActivityTitle);
        await verifyLabel(srp.firstActivityTitle, expected().disneyActivityTitleParis);
        console.log('Disney displays at first position in M1 view for Paris');
        console.log('Test PASS: Verifying Disney activity for M1 view | Paris in '+ getEndPoint());
    });
});

