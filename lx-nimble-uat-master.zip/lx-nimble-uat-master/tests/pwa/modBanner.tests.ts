'use strict';
import { getEndPoint, iPhonex, verifyLabel } from '../helpers/helper';
import { account, abacus, activityUrl } from '../urlFactory/urlFactoryPwa';
import { srp, destinationPage, infosite } from '../elementFactory/elementFactoryPwa';
import { expected } from '../expectationFactory/expectationFactoryPwa';

describe('LX PWA SRP page MOD Test in M0 view', () => {

    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:32659|0|0:35083|1|1'), { waitUntil: 'load' });
        await page.goto(getEndPoint() + account.modLogin, {
            waitUntil: 'load',
        });
        await page.emulate(iPhonex);
    });

    it('MOD badge test in M0 view', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        var activityCount = await page.evaluate(() => {return document.querySelectorAll('a.uitk-card-link').length});
        while (await page.$(srp.badgeOfferText) === null && await page.$(srp.showMore) !== null  && activityCount < 100){
            await page.click(srp.showMore);
            await page.waitForFunction( `document.querySelectorAll('a.uitk-card-link').length > ${activityCount}`);
            await page.waitFor(3000);//This is required as it found that it takes some time load the entire actvities
            activityCount = await page.evaluate(() => {return document.querySelectorAll('a.uitk-card-link').length});
        }

        await page.waitForSelector(srp.badgeOfferText);
        const texts = await page.evaluate(() => {
            const data = [];
            const elements = document.getElementsByClassName('uitk-badge-text');
            for (const element of elements) {
                data.push(element.textContent);

            }
            return data;
        });
        console.log('MOD Badge values for M0 mode are:', texts);
        await expect(texts).toContain(expected().modBannerBadgeText);
        console.log('Test PASS: MOD badge test in M0 view in '+getEndPoint());
    });

    it.skip('IS: MOD strike out price in M0 PWA mode', async () => {
        const modUrl = 'things-to-do/a.a429292.a';
        await page.goto((getEndPoint() + modUrl), { waitUntil: 'load' });
        await page.waitForSelector('.all-b-margin-four .uitk-price-lockup .uitk-type-300');
        const strikePrice = (await page.$$('.all-b-margin-four .uitk-price-lockup .uitk-type-300')).length;
        expect(strikePrice).toBeGreaterThan(0);

        const list = await page.evaluate(() => Array.from(document.querySelectorAll('.all-b-margin-four .uitk-price-lockup .uitk-type-300'),
            (element) => element.textContent), {
            waitUntil: 'load'
        });
        console.log('IS Striked out price list for MOD user:', list);
        const modBanner = (await page.$$('.uitk-badge-text')).length;
        await expect(modBanner).toBeGreaterThan(0);
    });

    it.skip('IS:MOD discount percentage in M0 PWA mode', async () => {
        const bannerUrl = 'things-to-do/a.a429292.a';
        await page.goto((getEndPoint() + bannerUrl), { waitUntil: 'load' });
        await page.waitForSelector('.uitk-badge-text');
        const mipPrice = (await page.$$('.uitk-badge-text')).length;
        expect(mipPrice).toBeGreaterThan(0);
        const list = await page.evaluate(() => Array.from(document.querySelectorAll('.uitk-badge-text'),
            (element) => element.textContent), {
            waitUntil: 'load'
        });
        console.log('IS discount list for MIP user:', list);
        const addonBanner = (await page.$$('.all-x-margin-three')).length;
        await expect(addonBanner).toBeGreaterThan(0);
    });

});

describe('LX PWA SRP page MOD Test in M1 view', () => {

    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=29685|1|1:31112|1|1:32659|1|1:35083|1|1'), { waitUntil: 'load' });
        await page.goto(getEndPoint() + account.modLogin, {
            waitUntil: 'load',
        });
        await page.emulate(iPhonex);
    });

    it('MOD badge test in Destination page M1 mode', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.waitForSelector(srp.activityTile);
        const texts = await page.evaluate(() => {
            const data = [];
            const elements = document.getElementsByClassName('uitk-badge-text');
            for (const element of elements) {
                data.push(element.textContent);
            }
            return data;
        });
        console.log('Badge texts values for Destination view in M1 mode are:', texts);
        await expect(texts).toContain(expected().modBannerBadgeText);
        console.log('Test PASS: MOD badge test in Destination page M1 mode in '+getEndPoint());
    });

    it('MOD badge test in List view M1 mode', async () => {
        await page.goto(getEndPoint() + activityUrl.singaporeSrp, { waitUntil: 'load' });
        await page.waitForSelector(destinationPage.Top10ThingsToDoSeeAll);
        await page.click(destinationPage.Top10ThingsToDoSeeAll);
        await page.waitForFunction(() => document.querySelectorAll('.uitk-card-link').length > 40, {
            polling: 'mutation',
        }, { waitUntil: 'load' });
        if (await page.$(srp.showMore) !== null){
            await page.click(srp.showMore);
        await page.waitForFunction(() => document.querySelectorAll('[data-testid="activity-tile"]').length > 90, {
            polling: 'mutation',
            }, { waitUntil: 'load' });
        }
        if (await page.$(srp.showMore) !== null){
        await page.click(srp.showMore);}
        await page.waitForSelector(srp.pillText);

        const texts = await page.evaluate(() => {
            const data = [];
            const elements = document.getElementsByClassName('uitk-badge-text');
            for (const element of elements) {
                data.push(element.textContent);

            }
            return data;
        });
        console.log('Badge texts values for List view M1 mode are:', texts);
        await expect(texts).toContain(expected().modBannerBadgeText);
        console.log('Test PASS: MOD badge test in List view M1 mode in '+getEndPoint());
    });
});

describe('LX PWA IS page MOD Discount and Strike through Price Test', () => {
    beforeAll(async () => {
        await page.goto(getEndPoint() + account.logout, { waitUntil: 'domcontentloaded' });
        await page.goto((getEndPoint() + abacus.abClean), { waitUntil: 'load' });
        await page.goto((getEndPoint() + 'tools/abacus/overrides?abov=35083|1|1'), { waitUntil: 'load' });
        await page.goto(getEndPoint() + account.modLogin, {
            waitUntil: 'load',
        });
        await page.emulate(iPhonex);
    });

    it('MOD Discount and Strike through Price Test on IS', async () => {
        await page.goto((getEndPoint() + activityUrl.modActivity), { waitUntil: 'load' });
        await page.waitForSelector(infosite.nonDiscountedOfferPrice);
        const strikePrice = await page.$eval('span.uitk-type-300 > del', (heading) => heading.textContent);
        await expect(strikePrice).toMatch(new RegExp('[1-9]*'));
        const discountPercentage = await page.$eval('span.uitk-badge-text', (heading) => heading.textContent);
        await expect(discountPercentage).toMatch(new RegExp('[1-99]% '+expected().discountText));
        console.log('Discount percentage and strickeou price shows correctly in IS page for MOD activity');
        console.log('Test PASS: MOD Discount and Strike through Price Test on IS in '+getEndPoint());
    });
});