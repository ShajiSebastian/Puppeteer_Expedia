export const abacus = {
    abClean: 'tools/abacus/overrides?clean=1',
};

export const account = {
    logout: 'devtools/account/userlogout',
    mipLogin: 'devtools/login?email=automationtest@expedia.com&password=test@123',
    modLogin: 'devtools/login?email=automodtest@expedia.com&password=expedia',
    swpLogin: 'devtools/login?email=automationtest@expedia.com&password=test@123',
};
export const activityUrl = {
    a171360: 'things-to-do/a.a171360.a',
    a234437: 'things-to-do/a.a234437.a',
    romeSrp: 'things-to-do/search?location=Rome (and vicinity), Lazio, Italy',
    losAngelesSrp: 'things-to-do/search?location=los angeles',
    orangeCountySrp: 'things-to-do/search?location=orange county',
    orlandoSrp: 'things-to-do/search?location=orlando',
    parisSrp: 'things-to-do/search?location=paris',
    singaporeSrp: 'things-to-do/search?location=Singapore, Singapore',
    modActivity: 'things-to-do/a.a376190.a',
    pinnedActivity: 'things-to-do/search?&location=Orlando,%20Florida&startDate=08/21/2019&endDate=08/21/2019&latLong=28.54129,-81.37904&rid=178294&regionType=MULTICITY&countryCode=US&selectedId=181205',
};
